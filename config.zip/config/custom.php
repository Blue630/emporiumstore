<?php
// return [
// 	'razor_key' => 'rzp_live_sTGJspl7JMJ1JI',
// 	'razor_secret' => 'wSb9F9P5KgPv54fIdlekfIhQ'
// ];
return [
	'razor_key' => 'rzp_live_sTGJspl7JMJ1JKI',
	'razor_secret' => 'wSb9F9P5KgPv54fIdlekefIhQ'
];
?>