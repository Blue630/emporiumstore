<?php echo $__env->make('front.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('header'); ?>
<!-- content area start -->
<div class="container ab-w  my-5">
    <div class="page_title about_us position-relative">
        <img src="https://development-review.net/emporium/public/pages/1639725369_Rectangle 95.png" class="img-fluid d-block mx-auto" alt="">
        <h1 class="ft-60 lh-90 ft-bold">404<br>Not Found</h1>
    </div>
</div>
<?php echo $__env->make('front.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('footer'); ?><?php /**PATH /home3/develsi8/public_html/emporium/resources/views/front/404.blade.php ENDPATH**/ ?>