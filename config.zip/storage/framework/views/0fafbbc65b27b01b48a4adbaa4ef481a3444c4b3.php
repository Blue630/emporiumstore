 <?php $__env->startSection('content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Advanced Form</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/subcategory/manage_subcategory')); ?>" class="btn btn-primary"><i class="fas fa-backward"></i>&nbsp;</i>Back</a></li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">

          <div class="card-body">
            <?php if($msg=Session::get('success')): ?>
            <div class="alert alert-success"><?php echo e($msg); ?></div>
            <?php endif; ?>
            <form method="post" action="<?php echo e(url('admin/subcategory/edit_subcategory')); ?>/<?php echo e($subcate->id); ?>" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
            <div class="row">
              
              <div class="col-md-12">

                <div class="form-group">
                  <label>Parent Category</label>
                  <select name="parent_cat" id="parent_cat" class="form-control">
                    <option value="1" <?php if($subcate->parent_cat==1): ?> <?php echo e("selected"); ?> <?php endif; ?>>Export</option>
                    <option value="2" <?php if($subcate->parent_cat==2): ?> <?php echo e("selected"); ?> <?php endif; ?>>Import</option>
                  </select>
                   <span class="text-danger"><?php echo e($errors->first('parent_cat')); ?></span>
                </div>

                <div class="form-group">
                  <label>Category</label>
                  <select name="cate_id" id="cate_id" class="form-control">
                    <option>Select</option>
                    <?php if($category): ?>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($allcategory->id); ?>" <?php if($allcategory->id==$subcate->cate_id): ?><?php echo e("selected"); ?> <?php endif; ?>><?php echo e($allcategory->catename); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </select>
                   <span class="text-danger"><?php echo e($errors->first('cate_id')); ?></span>
                </div>

                <div class="form-group">
                  <label>Sub Category</label>
                  <input type="text" name="subcate" id="subcate" class="form-control" value="<?php if($subcate): ?><?php echo e($subcate->subcate); ?> <?php endif; ?>">
                   <span class="text-danger"><?php echo e($errors->first('subcate')); ?></span>
                </div>

                <div class="form-group">
                  <label>Image</label>
                  <input type="file" name="image" id="image" class="form-control">
                </div>

              </div>

            </div>
            <div class="">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
           
          </div>

        </div>

      </div>
    </section>

  </div>
  <?php $__env->startSection('script'); ?>

  <script type="text/javascript">
  
    $(document).ready(function(){
       $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    } });
      $('#parent_cat').on('change',function(){
        //alert();
        var parent_cat=$(this).val();
        //alert(parent_cat);
        $.ajax({
          url : '<?php echo e(url("/admin/subcategory/fetch_category")); ?>',
          method : 'post',
          data : {parent_cat:parent_cat},
          type : 'html',
          success : function(data)
          {
            //alert(data); return false;
           $('#cate_id').html(data);
          }
        });

      });
    });
  </script>
  <?php $__env->stopSection(); ?>
   <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('admin/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\cuthbert_group\resources\views/admin/subcategory/edit_subcate.blade.php ENDPATH**/ ?>