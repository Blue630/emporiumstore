<div class="search-form-container-full">
    <div class="container">
        <div class="row">
            <div class="col-sm-7 offset-sm-3 search-wrap">
                <div class="text-center middle">
                    <form class="search-form" method="post" action="<?php echo e(url('/search')); ?>">
                    <?php echo csrf_field(); ?>
                        <input type="search" class="search-field" value="" name="searchdata" placeholder="What are you searching for?" />
                        <button class="button-search" type="submit">
                            <i class="pe-7s-search"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /home3/develsi8/public_html/laravel/resources/views/front/include/head_search.blade.php ENDPATH**/ ?>