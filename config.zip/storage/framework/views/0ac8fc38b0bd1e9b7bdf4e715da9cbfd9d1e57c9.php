 

 <?php $__env->startSection('content'); ?>
 
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Book VIP Number</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Book VIP Number</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <style>
        .homelogo {
            background: #fff;
            padding: 30px;
            text-align: center;
        }
        .small-box>.small-box-footer {
            background: rgb(62 62 62 / 48%);
            color: rgba(255,255,255,.8);
            display: block;
            padding: 3px 0;
            position: relative;
            text-align: center;
            text-decoration: none;
            z-index: 10;
        }
        .bg-warning {
            background-color: #909090 !important;
        }
        .bg-info {
            background-color: #4a4a4a !important
        }
    </style>
    <section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?php echo e($neworder); ?></h3>
                        <p>New Orders</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="#" class="small-box-footer">&nbsp;</a>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?php echo e($totaloders); ?><!--<sup style="font-size: 20px;">%</sup>--></h3>
                        <p>Total Orders</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-stats-bars"></i>
                    </div>
                    <a href="#" class="small-box-footer">&nbsp;</a>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?php echo e($totalproducts); ?></h3>
                        <p>Total Products</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                    <a href="#" class="small-box-footer">&nbsp;</a>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?php echo e($totaluser); ?></h3>
                        <p>Total User</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>
                    </div>
                    <a href="#" class="small-box-footer">&nbsp;</a>
                </div>
            </div>
        </div>
    </div>
</section>
    <!-- /.content-header -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="homelogo">
                    <img src="<?php echo e(asset('/public/front')); ?>/images/logo-1.png" alt="" />
                </div>
            </div>
        </div>
    </div>
    <div class="container">
    <div class="row">
        <div class="col-md-12" style="padding: 15px;">
            <!-- <form class="form-inline" action="">
              <label>Margin Setup</label>&nbsp;&nbsp;&nbsp;&nbsp;
              <input type="text" class="form-control" placeholder="Margin Setup">&nbsp;&nbsp;&nbsp;&nbsp;
                  <label for="sel1">Select Type:</label>
                  <select class="form-control" id="sel1">
                    <option>Distributor Seller</option>
                    <option>Distributor Buyer</option>
                    <option>Buyer Panel</option>
                  </select>&nbsp;&nbsp;&nbsp;&nbsp;
              <button type="submit" class="btn btn-primary">Submit</button>
            </form> -->
        </div>
    </div>
</div>

    <!-- Main content -->
   <section class="content">
    <div class="container-fluid">
        <div class="row">
            <!--<div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-info elevation-1"><i class="fas fa-cog"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">CPU Traffic</span>
                        <span class="info-box-number">
                            10
                            <small>%</small>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-3">
                    <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-thumbs-up"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Likes</span>
                        <span class="info-box-number">41,410</span>
                    </div>
                </div>
            </div>-->
            <div class="clearfix hidden-md-up"></div>
            <div class="col-12 col-sm-6 col-md-6">
                <div class="info-box mb-3">
                    <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-users"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Total Seller</span>
                        <span class="info-box-number"><?php echo e($totalvendor); ?></span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-6">
                <div class="info-box mb-3">
                    <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-users"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Total Buyer</span>
                        <span class="info-box-number"><?php echo e($totalbuyer); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- /.content -->
  </div>
 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\bookvipnumber\resources\views/adminHome.blade.php ENDPATH**/ ?>