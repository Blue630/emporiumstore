 
    <?php $__env->startSection('content'); ?>
            <div id="main">
                <div class="section section-bg-53 section-cover pt-10 pb-10">
                    <div class="bg-overlay"></div>
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="text-center">
                                    <h2 class="fz-70 white"><b>Book VIP Number</b></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section pb-6 pt-6">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-4 pb-4">
                                <img src="<?php if($buyerdetail->profile_img): ?><?php echo e(asset('/public/uploads/buyer')); ?>/<?php echo e($buyerdetail->profile_img); ?><?php else: ?><?php echo e(asset('/public/uploads/buyer')); ?>/<?php echo e('demo.jpg'); ?><?php endif; ?>" class="img-fluid img-thumbnail w-100">
                                <?php if(!empty($order_detail)): ?>
                                <?php $wallet=0;?>
                                  <?php $totalprice=0;?>
                                        <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                        $totalprice=$allorder->total;
                                        $wallet=(($totalprice*10)/100);
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <p ><b>Wallet Balance(INR):</b> <span style="color:green"><?php echo e($wallet); ?>.00/</span></p>
                                <?php endif; ?>        
                            </div>
                            <div class="col-sm-8">
                                <p><b>Name:</b><?php if($buyerdetail->name): ?><?php echo e($buyerdetail->name); ?><?php endif; ?><button class="btn btn-rounded btn-bg-dark" style="float: right;" data-toggle="modal" data-target="#exampleModalCenter"><a href="#" style="color: #fff;">Edit Profile</a></button> </p>
                                <p><b>Email:</b> <?php if($buyerdetail->email): ?><?php echo e($buyerdetail->email); ?><?php endif; ?></p>
                                <p><b>Phone:</b> +91 <?php if($buyerdetail->phone): ?><?php echo e($buyerdetail->phone); ?><?php endif; ?></p>
                                <p><b>Store Name:</b> <?php if($buyerdetail->storename): ?><?php echo e($buyerdetail->storename); ?><?php endif; ?></p>
                                <p><b>Bio:</b> <?php if($buyerdetail->storedetail): ?><?php echo e($buyerdetail->storedetail); ?><?php endif; ?> </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                            <?php if(!empty($order_detail)): ?>
                                <table class="table shop-cart">
                                    <thead>
                                        <tr>
                                            <th class="product-thumbnail">Product</th>
                                            <th class="product-name">Price</th>
                                            <th class="product-subtotal">Total(10%)</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                   
                                    <?php $totalprice=0;?>
                                        <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="cart_item">
                                            <td class="product-name" data-title="Product">
                                                <a href="#"><?php echo e($allorder->productname); ?></a>
                                            </td>
                                            <td class="product-price" data-title="Price">
                                                <span class="amount"><i class="fa fa-inr"></i><?php echo e($allorder->total); ?></span>
                                            </td>
                                            <td class="product-subtotal" data-title="SubTotal">
                                                <span class="amount"><i class="fa fa-inr"></i><?php echo e($allorder->total); ?></span>
                                            </td>
                                        </tr>
                                        <?php $totalprice=$totalprice+$allorder->total;?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                       
                                    </tbody>
                                    <tfoot style="background: #eee;">
                                        <tr>
                                            <th class="product-thumbnail">Product</th>
                                            <th class="product-name">&nbsp;</th>
                                            <th class="product-subtotal">Total Price <?php echo e($totalprice); ?>/-</th>
                                        </tr>
                                    </tfoot>
                                   
                                </table>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Update Profile</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo e(url('/buyprofileupdate')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="buyer_id" value="<?php if($buyerdetail->id): ?><?php echo e($buyerdetail->id); ?><?php endif; ?>">
            <div class="form-group">
              <label>Profile Image</label>
            <input type="file" class="form-control" id="profile_img" name="profile_img" >
            </div>

            <div class="form-group">
              <label>Description</label>
           <textarea name="storedetail" id="storedetail" cols="30" rows="10" class="form-control"><?php if($buyerdetail->storedetail): ?><?php echo e($buyerdetail->storedetail); ?><?php endif; ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Save changes</button>
        </form>
      </div>
     
    </div>
  </div>
</div>
            <?php $__env->stopSection(); ?>

            <!-- Button trigger modal -->

<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/w9wyzh39hnz2/public_html/resources/views/front/buyer/buyerprofile.blade.php ENDPATH**/ ?>