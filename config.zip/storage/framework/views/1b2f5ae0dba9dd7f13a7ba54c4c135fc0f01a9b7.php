 <?php $__env->startSection('content'); ?>
 <!-- <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script> -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Product</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/vendor/manageproduct')); ?>" class="btn btn-primary"><i class="fas fa-backward"></i>&nbsp;</i>Back</a></li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">

          <div class="card-body">
            <?php if($msg=Session::get('success')): ?>
            <div class="alert alert-success"><?php echo e($msg); ?></div>
            <?php endif; ?>
            <form method="post" action="<?php echo e(url('vendor/editproduct')); ?>/<?php echo e($productdetail->id); ?>" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
            <div class="row">
              
              <div class="col-md-12">

                <div class="form-group">
                  <label>Category</label>
                  <select name="catid" id="" class="form-control" required>
                    <option value="">Select Category</option>
                    <?php if($cate): ?>
                      <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allcate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($allcate->id); ?>" <?php if($productdetail->catid==$allcate->id): ?><?php echo e("selected"); ?><?php endif; ?>><?php echo e($allcate->catname); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                  </select>
                </div>

                <div class="form-group">
                  <label>Product Number</label>
                  <input type="text" name="productnumber" required class="form-control" value="<?php if($productdetail): ?><?php echo e($productdetail->productnumber); ?><?php endif; ?>">
                </div>

                <div class="form-group">
                  <label>Price</label>
                  <input type="text" name="price" required class="form-control" value="<?php if($productdetail): ?><?php echo e($productdetail->price); ?><?php endif; ?>">
                </div>

              </div>

            </div>
            <div class="">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
           
          </div>

        </div>

      </div>
    </section>

  </div>

  <!-- <?php $__env->startSection('script'); ?>
  <script>
    CKEDITOR.replace( 'details' );    
</script>
  <?php $__env->stopSection(); ?> -->
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('vendor.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_test\resources\views/vendor/product/edit_product.blade.php ENDPATH**/ ?>