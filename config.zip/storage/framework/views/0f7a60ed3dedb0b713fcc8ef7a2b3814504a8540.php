 <?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Pending Orders</h1>
                </div>
                <!-- <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/add_healthcare')); ?>" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>Add New</a></li>

                    </ol>
                </div> -->
            </div>
        </div>
    </section>
    <style>
        .btn-11 {
            padding: 4px 7px;
            font-size: 14px;
            text-align: center;
        }
    </style>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-default">
            	  <?php if($success=Session::get('success')): ?>
    <div class="alert alert-primary"><?php echo e($success); ?></div>
    <?php endif; ?>
                <div class="card-body">
                <div class="alert alert-warning"><b>Manage Customers Orders</b></div>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>SNo.</th>
                                <th>Order Id</th>
                                <th>Product Name</th>
                                <th>Product Thumbnail</th>
                                <th>Buyer Name</th>
                                <th>Quantity</th>
                                <th>Amount</th>
                                <th>Message</th>
                                <th>Order Details</th>
                            </tr>
                        </thead>
                        <tbody>
                      

                        </tbody>
                        <tfoot>
                            <tr>
                                <th>SNo.</th>
                                <th>Order Id</th>
                                <th>Product Name</th>
                                <th>Product Thumbnail</th>
                                <th>Buyer Name</th>
                                <th>Quantity</th>
                                <th>Amount</th>
                                <th>Message</th>
                                <th>Order Details</th>
                            </tr>
                        </tfoot>


                    </table>

                </div>

            </div>

        </div>
    </section>
  
    
    <!--==================================== Buyer========================================= -->
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Send Porting Code</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo e(url('/admin/sendportingcode')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
            <div class="form-group">
              <label>Email To</label>
            <input type="text" class="form-control" id="sendto" name="sendto" required>
            </div>

            <div class="form-group">
              <label>Product Number</label>
            <input type="text" class="form-control" id="prodnumber" name="prodnumber" readonly>
            </div>
            <div class="form-group">
              <label>Porting Code</label>
            <input type="text" class="form-control" id="portingcode" name="portingcode" required>
            </div>

            <button type="submit" class="btn btn-primary">Send Code</button>
        </form>
      </div>
     
    </div>
  </div>
</div>
<?php $__env->startSection('script'); ?>

<!-- page script -->
<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });
    $(document).ready(function() {
        $('#example1').DataTable();
        $('#example2').DataTable();
    });
</script>
<script>
    $(document).ready(function() {
        $('.delete_btn').click(function() {
            var id = $(this).attr('id');
            if (confirm('Are you sure want to delete ?')) {
                document.location.href = '<?php echo e(url("/admin/")); ?>' + '/' + id;
            } else {
                return false;
            }
        });
    });
</script>
<script>
$(document).ready(function(){
    $('.portingcode').click(function(){
        let id=$(this).attr('id');
        //alert(id);
        let proname=$('#proname_'+id).val();
        let toemail=$('#toemail_'+id).val();
        $('#prodnumber').val(proname);
        $('#sendto').val(toemail);
    });
});
</script>
<?php $__env->stopSection(); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/develsi8/public_html/laravel/resources/views/admin/order/manage-pending-orders.blade.php ENDPATH**/ ?>