<?php echo $__env->make('front.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('header'); ?>
<!-- content area start -->
<div class="container px-5">
    <section id="home_slideshow">
        <div id="owl_slideshow" class="owl-carousel owl-theme big_arrow">
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Banner.png" alt=""></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Banner.png" alt=""></a>
            </div>
        </div>
    </section>
</div>

<div class="container">
    <section id="featured_prod" class="slider_sec">
        <div class="row align-items-center">
            <div class="col-lg-3 pb-5 pb-lg-0">
                <h3 class="ft-25 text-white m-0">Featured Products</h3>
            </div>
            <div class="col-lg-9">
                <div class="owl-carousel boxed_arrow" id="stagepadding1">
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 101.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 91.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 91.png" class="shadow" alt="" /></a>
                    </div>
                </div>
            </div>

        </div>
        <div class="text-end pt-4 pe-5"><a href="#" class="ft-18 text-white">VIEW ALL</a></div>
    </section>
</div>
<div class="container">
    <section id="category-list">
        <h3 class="text-center ft-25 my-5 pt-3">CATEGORIES</h3>
        <div id="category_list" class="owl-carousel owl-theme big_arrow arrow_padding">
            <?php
            if($category!="")
            {
            foreach ($category as $allcategory) 
            {
            $id = $allcategory->id;
            ?>
            <div class="item">
                <a href="<?php echo e(url('/category/').$id); ?>"><img src="<?php echo e(asset('public/category/'.$allcategory->categoryimg)); ?>" class="rounded-circle shadow" alt="" />
                    <p class="ft-18 mt-4 text-black text-center"><?php echo e($allcategory->catname); ?></p>
                </a>
            </div>
            <?php
            }
            }
            ?>
        </div>
    </section>
    <div class="text-end pt-4 pe-5"><a href="#" class="ft-18 pr-30 text-black">VIEW ALL</a></div>
</div>
<div class="container mt-5 pt-4">
    <section id="todays-deal" class="slider_sec shadow-set px-30 py-20 pb-4">
        <div class="row align-items-center">
            <div class="col-lg-3 pb-5 pb-lg-0">
                <h3 class="ft-25 text-black m-0">Today’s deal</h3>
            </div>
            <div class="col-lg-9">
                <div class="owl-carousel boxed_arrow boxed_arrow_black" id="todaysDeal">
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 101.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 91.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 91.png" class="shadow" alt="" /></a>
                    </div>
                </div>
            </div>

        </div>
        <div class="text-end pt-4 pe-5"><a href="#" class="ft-18 text-black">VIEW ALL</a></div>
    </section>
</div>
<div class="container mt-5 pt-4">
    <section id="best-seller">
        <h3 class="text-center ft-25 my-5 pt-3">OUR BEST SELLER</h3>
        <div id="bestseller" class="owl-carousel owl-theme big_arrow arrow_padding">
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 101.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="rounded-circle shadow" alt="" /></a>
            </div>
        </div>
    </section>
    <div class="text-end pt-4 pe-5"><a href="#" class="ft-18 pr-30 text-black">VIEW ALL</a></div>
</div>
<div class="container mt-5 pt-4">
    <section id="top-rated" class="slider_sec shadow-set px-30 py-20 pb-4">
        <div class="row align-items-center">
            <div class="col-lg-2 pb-5 pb-lg-0">
                <h3 class="ft-25 text-black m-0">Top Rated</h3>
            </div>
            <div class="col-lg-10">
                <div class="owl-carousel boxed_arrow boxed_arrow_black" id="toprated">
                    <div class="item">
                        <a href="#">
                            <p>Fashion</p><img src="<?php echo e(asset('/public/front')); ?>/img/Group 3.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#">
                            <p>Mobile & Accessories</p><img src="<?php echo e(asset('/public/front')); ?>/img/Group 4.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#">
                            <p>Electronics</p><img src="<?php echo e(asset('/public/front')); ?>/img/Group 5.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#">
                            <p>Home & Garden</p><img src="<?php echo e(asset('/public/front')); ?>/img/Group 3.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#">
                            <p>Fashion</p><img src="<?php echo e(asset('/public/front')); ?>/img/Group 4.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#">
                            <p>Electronics</p><img src="<?php echo e(asset('/public/front')); ?>/img/Group 5.png" class="shadow" alt="" /></a>
                    </div>
                </div>
            </div>

        </div>
        <div class="text-end pt-4 pe-5"><a href="#" class="ft-18 text-black">VIEW ALL</a></div>
    </section>
</div>
<div class="container mt-5 pt-4">
    <section id="just-launched">
        <h3 class="text-center ft-20 my-5 pt-3">JUST LAUNCHED/ Just in/ newly ADDED</h3>
        <div id="justlaunched" class="owl-carousel owl-theme big_arrow arrow_padding">
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 101.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="rounded-circle shadow" alt="" /></a>
            </div>
        </div>
    </section>
    <div class="text-end pt-4 pe-5"><a href="#" class="ft-18 pr-30 text-black">VIEW ALL</a></div>
</div>
<div class="container my-5 pt-5">
    <section id="weekly-deals" class="slider_sec shadow-set px-30 py-20 pb-4">
        <div class="row align-items-center">
            <div class="col-lg-3 pb-5 pb-lg-0">
                <h3 class="ft-25 text-black m-0">Weekly Deals</h3>
            </div>
            <div class="col-lg-9">
                <div class="owl-carousel boxed_arrow boxed_arrow_black" id="weeklydeals">
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 101.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 91.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 91.png" class="shadow" alt="" /></a>
                    </div>
                </div>
            </div>

        </div>
        <div class="text-end pt-4 pe-5"><a href="#" class="ft-18 text-black">VIEW ALL</a></div>
    </section>
</div>
<div class="container mt-5 pt-4">
    <section id="early-sale">
        <h3 class="text-center ft-20 my-5 pt-3">Early Winter Sale/ Summer Sale/ Autumn Sale/ rainy Season deals</h3>
        <div id="earlysale" class="owl-carousel owl-theme big_arrow arrow_padding">
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 101.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="rounded-circle shadow" alt="" /></a>
            </div>
        </div>
    </section>
    <div class="text-end pt-4 pe-5"><a href="#" class="ft-18 pr-30 text-black">VIEW ALL</a></div>
</div>
<div class="container mt-5 py-5">
    <div class="row">
        <div class="col-lg-10 col-xl-8 mx-auto">
            <section class="rate_purchase border p-lg-5">
                <div class="p-4">
                    <h2 class="ft-35 text-black text-center pb-5">RATE YOUR PURCHASE</h2>

                    <div class="row pt-4">
                        <div class="col-md-3 text-center">
                            <img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 23.png" class="img-fluid mb-4" alt="">
                        </div>
                        <div class="col-md-9 px-4">
                            <h3 class="ft-25 text-black text-center">ADDIDAS SOLID MEN’S TRACK PANT</h3>
                            <div class="d-flex align-items-start justify-content-center starbox gap-5 py-5">
                                <div class="star1">
                                    <label for="1star"><input type="radio" id="1star" name="starrating"><span class="show_star"></span></label>
                                    <p class="ft-13 ft-light">HATED IT</p>
                                </div>
                                <div class="star2">
                                    <label for="2star"><input type="radio" id="2star" name="starrating"><span class="show_star"></span></label>
                                    <p class="ft-13 ft-light">DIDN’T LIKE</p>
                                </div>
                                <div class="star3">
                                    <label for="3star"><input type="radio" id="3star" name="starrating"><span class="show_star"></span></label>
                                    <p class="ft-13 ft-light">WAS OKAY</p>
                                </div>
                                <div class="star4">
                                    <label for="4star"><input type="radio" id="4star" name="starrating"><span class="show_star"></span></label>
                                    <p class="ft-13 ft-light">LIKED</p>
                                </div>
                                <div class="star5">
                                    <label for="5star"><input type="radio" id="5star" name="starrating"><span class="show_star"></span></label>
                                    <p class="ft-13 ft-light">LOVED IT</p>
                                </div>
                            </div>
                            <div class="text-center">
                                <input type="submit" value="SUBMIT" class="px-5">
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<div class="container my-5 pt-5">
    <section id="month-deals" class="slider_sec shadow-set px-30 py-20 pb-4">
        <div class="row align-items-center">
            <div class="col-lg-3 pb-5 pb-lg-0">
                <h3 class="ft-25 text-black m-0">DEAL OF THE MONTH</h3>
            </div>
            <div class="col-lg-9">
                <div class="owl-carousel boxed_arrow boxed_arrow_black" id="monthdeals">
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 101.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 91.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 91.png" class="shadow" alt="" /></a>
                    </div>
                </div>
            </div>

        </div>
        <div class="text-end pt-4 pe-5"><a href="#" class="ft-18 text-black">VIEW ALL</a></div>
    </section>
</div>

<div class="container mt-5 pt-4">
    <section id="top-picks">
        <h3 class="text-center ft-20 my-5 pt-3">TOP pICKS FOR YOU</h3>
        <div id="toppicks" class="owl-carousel owl-theme big_arrow arrow_padding">
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 101.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="rounded-circle shadow" alt="" /></a>
            </div>
            <div class="item">
                <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="rounded-circle shadow" alt="" /></a>
            </div>
        </div>
    </section>
    <div class="text-end pt-4 pe-5"><a href="#" class="ft-18 pr-30 text-black">VIEW ALL</a></div>
</div>
<div class="container my-5 pt-5">
    <h3 class="ft-25 text-black my-5 p-4">CONTINUE WHERE YOU LEFT</h3>
    <section id="continue-left" class="slider_sec shadow-set px-30 py-20 pb-4">
        <div class="row align-items-center">
            <div class="col-lg-12">
                <div class="owl-carousel boxed_arrow boxed_arrow_black" id="continueleft">
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 101.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 10.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 91.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 11.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 9.png" class="shadow" alt="" /></a>
                    </div>
                    <div class="item">
                        <a href="#"><img src="<?php echo e(asset('/public/front')); ?>/img/Rectangle 91.png" class="shadow" alt="" /></a>
                    </div>
                </div>
            </div>

        </div>

    </section>
    <div class="text-end pt-5 pe-5"><a href="#" class="ft-18 text-black">VIEW ALL</a></div>
</div>
<div class="h-50px"></div>
<section id="signup_newsletter" class="my-5 py-5 px-5">
    <div class="d-lg-flex align-items-center justify-content-center">
        <h2 class="ft-35 lh-50 text-black text-center pb-4 pb-lg-0">Sign-Up to Our Newsletter</h2>
        <div class="sub_button ps-lg-5 ms-lg-5">
            <a href="#" class="blue_btn btn-large ft-35 text-center">SUBSCRIBE</a>
        </div>
    </div>
</section>
<div class="h-50px"></div>        
<?php echo $__env->make('front.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('footer'); ?><?php /**PATH /home3/develsi8/public_html/laravel/resources/views/front/index.blade.php ENDPATH**/ ?>