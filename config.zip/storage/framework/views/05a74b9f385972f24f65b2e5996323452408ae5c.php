
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      
    </ul>
  </nav>
  <!-- sidebar -->
  <style>
      .nav-pills .nav-link.active, .nav-pills .show > .nav-link {
            color: #fff;
            background-color: #007bff;
            margin-bottom: 0px;
        }
        .nav-sidebar>.nav-item {
            margin-bottom: 0;
            border-bottom: 1px dotted #33333363;
        }
        .layout-fixed .main-sidebar{
            background: #000;
            color: #fff;
        }
        .nav-pills .nav-link {
            color: #c5c5c5;
        }
        .nav-pills .nav-link:not(.active):hover {
            color: #ffffff;
        }
  </style>

  <aside class="main-sidebar elevation-4">
        <!-- Sidebar -->
    <div class="sidebar" style="margin-top: 0px;">
      <!-- Sidebar user panel (optional) -->
      <!--<div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('/public/admin')); ?>/dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"> <?php if(Auth::check()): ?><?php echo e(auth()->user()->name); ?><?php endif; ?></a>
        </div>
      </div>-->

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <?php if(Auth::check()): ?>
          <?php if(Auth()->user()->is_admin==1): ?>
          <h5>Admin</h5>
          <li class="nav-item">
            <a href="<?php echo e(url('/admin/home')); ?>" class="nav-link <?php echo e((request()->is('admin/home'))? 'active' : ''); ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <!-- <i class="right fas fa-angle-left"></i> -->
              </p>
            </a>            
          </li>
            <?php else: ?>
            <h5>Super Admin</h5>
          <li class="nav-item">
            <a href="<?php echo e(url('/admin/dashboard')); ?>" class="nav-link <?php echo e((request()->is('admin/dashboard'))? 'active' : ''); ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <!-- <i class="right fas fa-angle-left"></i> -->
              </p>
            </a>
            
          </li>
          <!-- <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Lazer Report
              </p>
            </a>
            
          </li> -->
          <?php endif; ?>
          <?php endif; ?>

          <?php if(Auth::check()): ?>
          <?php if(Auth()->user()->is_admin==1): ?>                
          <li class="nav-item">
            <a href="<?php echo e(url('/admin/manageorder')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'manageorder')? 'active' : ''); ?>">
              <i class="nav-icon fas fa-th"></i>
              <p>Manage Orders</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(url('/admin/manage_cate')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'manage_cate' || request()->segment(2) =='add_cate' || request()->segment(2)=='edit_cate')? 'active' : ''); ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>Manage Category</p>
            </a>            
          </li>
          <li class="nav-item">
            <a href="<?php echo e(url('/admin/manageproduct')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'addprodouct' || request()->segment(2) =='manageproduct' || request()->segment(2)=='editproduct')? 'active' : ''); ?>">
              <i class="nav-icon fas fa-th"></i>
              <p>Manage Product</p>
            </a>            
          </li>

          <li class="nav-item">
            <a href="<?php echo e(url('/admin/manageusers')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'manageusers')? 'active' : ''); ?>">
              <i class="nav-icon fas fa-users"></i>
              <p>Manage Users</p>
            </a>            
          </li>
          <?php else: ?>
          <h5>Distributor Seller</h5>
          <li class="nav-item">
            <a href="<?php echo e(url('/admin/managevendor')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'managevendor')? 'active' : ''); ?>">
              <i class="nav-icon fas fa-users"></i>
              <p>Manage Vendors</p>
            </a>            
          </li>

          <li class="nav-item">
            <a href="<?php echo e(url('/admin/manageorder')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'manageorder')? 'active' : ''); ?>">
              <i class="nav-icon fas fa-th"></i>
              <p>Manage Orders</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(url('/admin/dailysale')); ?>" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>Daily Sales Report</p>
            </a>            
          </li>
          <h5>Distributor Buyer</h5>
          <li class="nav-item">
            <a href="<?php echo e(url('/admin/managebuyer')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'managebuyer')? 'active' : ''); ?>">
              <i class="nav-icon fas fa-users"></i>
              <p>Distributor Buyer</p>
            </a>            
          </li>

          <li class="nav-item">
            <a href="<?php echo e(url('/admin/managebuyerorder')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'managebuyerorder')? 'active' : ''); ?>">
              <i class="nav-icon fas fa-th"></i>
              <p>Manage Orders</p>
            </a>            
          </li>
          <li class="nav-item">
            <a href="<?php echo e(url('/admin/dailybuy')); ?>" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>Daily Sales Report</p>
            </a>            
          </li>
         <?php endif; ?>
         <?php endif; ?>          
          <?php if(Auth::check()): ?>
          <li class="nav-item">            
            <a href="<?php echo e(url('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="nav-link"> <i class="nav-icon fas fa-power-off"></i><p><?php echo e(__('Logout')); ?></p></a>
            <form id="logout-form" action="<?php echo e(url('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
          </li>
            <?php endif; ?>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH C:\xampp\htdocs\laravel_test\resources\views/admin/includes/header.blade.php ENDPATH**/ ?>