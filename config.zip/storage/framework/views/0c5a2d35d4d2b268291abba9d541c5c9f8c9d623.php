<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1.0" />
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="description" content=""/>
<meta name="keywords" content="" />
<meta name="author" content=""/>
<!-- <link href="images/favicon.png" rel="shortcut icon" type="image/png" /> -->
<link href="<?php echo e(asset('/public/front')); ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/public/front')); ?>/css/jquery-ui.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/public/front')); ?>/css/animate.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/public/front')); ?>/css/css-plugin-collections.css" rel="stylesheet" />
<link id="menuzord-menu-skins" href="<?php echo e(asset('/public/front')); ?>/css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet" />
<link href="<?php echo e(asset('/public/front')); ?>/css/style-main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/public/front')); ?>/css/preloader.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/public/front')); ?>/css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/public/front')); ?>/css/responsive.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/public/front')); ?>/js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/public/front')); ?>/js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/public/front')); ?>/js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/public/front')); ?>/css/colors/theme-skin-orange.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/public/front')); ?>/css/style.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
<script src="<?php echo e(asset('/public/front')); ?>/js/jquery-2.2.4.min.js"></script>
<script src="<?php echo e(asset('/public/front')); ?>/js/jquery-ui.min.js"></script>
<script src="<?php echo e(asset('/public/front')); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('/public/front')); ?>/js/jquery-plugin-collection.js"></script>
<script src="<?php echo e(asset('/public/front')); ?>/js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="<?php echo e(asset('/public/front')); ?>/js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script><?php /**PATH E:\xampp\htdocs\ensurecare\resources\views/front/include/meta_head.blade.php ENDPATH**/ ?>