    <?php $__env->startSection('content'); ?>
            <div id="main">
                <div class="section section-bg-53 section-cover pt-10 pb-10">
                    <div class="bg-overlay"></div>
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="text-center">
                                    <h2 class="fz-70 white"><b>Register</b></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section pb-6">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-3"></div>
                            <div class="col-sm-6 pt-5 pb-5">
                                <h2 class="fz-24 text-center"><b>Register</b><br><?php if($msg=Session::get('success')): ?><span style="color:red"><?php echo e($msg); ?></span><?php endif; ?></h2>
                                <form class="login" method="post" action="<?php echo e(url('registeration')); ?>">
                                <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label for="username">Name <span class="required">*</span></label>
                                            <input type="text" class="input-text" name="name" id="name" required/>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="email">Email <span class="required">* <?php echo e($errors->first('email')); ?></span></label>
                                            <input type="email" class="input-text" name="email" id="email" required/>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="phone">Phone <span class="required">*</span></label>
                                            <input type="number" class="input-text" name="phone" id="phone" required/>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="password">Password <span class="required">*</span></label>
                                            <input class="input-text" type="password" name="password" id="" required/>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="password">Confirm Password <span class="required">* <?php echo e($errors->first('cpassword')); ?></span></label>
                                            <input class="input-text" type="password" name="cpassword" id="" required />
                                        </div>
                                        <div class="col-md-12">
                                            <!-- <a class="btn btn-bg-dark mb-1" href="#">Submit</a> -->
                                            <input type="submit" value="Submit" class="btn btn-bg-dark mb-1">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-sm-3"></div>
                        </div>
                    </div>
                </div>
            </div>
           <?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_test\resources\views/front/registeration.blade.php ENDPATH**/ ?>