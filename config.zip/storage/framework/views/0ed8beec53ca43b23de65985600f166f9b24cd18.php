 
    <?php $__env->startSection('content'); ?>        
            <div id="main">
                <div class="section">
                    <div class="container-fluid desktop-none" style="padding: 0px; margin-top: 10%;">
                        <div class="row">
                            <div class="col-md-12">
                                <div id="demo" class="carousel slide" data-ride="carousel">
                                  <!-- The slideshow -->
                                  <div class="carousel-inner">
                                    <div class="carousel-item active">
                                      <img src="<?php echo e(asset('/public/front')); ?>/images/slider/banner-img.gif" style="width: 100%;">
                                      <div class="carousel-caption">
                                        <h3><small>BOOK VIP NUMBER</small><br>PREMIUM NUMBERS</h3>
                                        <p>Because number matters in our digital World...  <br>India's only oldest trusted website - TRUSTED & CERTIFIED COMPANY (SINCE 2001)</p>
                                        <a href="<?php echo e(url('/product-list')); ?>" style="color: rgb(41, 151, 255);">Get now ></a>
                                      </div>
                                    </div>
                                    <div class="carousel-item">
                                      <img src="<?php echo e(asset('/public/front')); ?>/images/slider/banner-3.jpg" style="width: 100%;">
                                    </div>
                                    <div class="carousel-item">
                                      <img src="<?php echo e(asset('/public/front')); ?>/images/slider/banner-2.jpg" style="width: 100%;">
                                    </div>
                                  </div>
                                
                                  <!-- Left and right controls -->
                                  <!--<a class="carousel-control-prev" href="#demo" data-slide="prev">
                                    <span class="carousel-control-prev-icon"></span>
                                  </a>
                                  <a class="carousel-control-next" href="#demo" data-slide="next">
                                    <span class="carousel-control-next-icon"></span>
                                  </a>-->
                                
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid mb-none">
                        <div class="row">
                            <div class="col-sm-12 p-0">
                                <div id="rev_slider_2" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.1">
									<ul>	
										<!-- SLIDE  -->
										<li data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300" data-rotate="0" data-saveperformance="off" data-title="Slide">

											<img src="<?php echo e(asset('/public/front')); ?>/images/slider/banner-img.gif" alt="" title="" width="1920" height="1000" data-bgposition="center center" data-kenburns="on" data-duration="10000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-blurstart="0" data-blurend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="off" class="rev-slidebg" />

											<div class="tp-caption Heli-Text-12 tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['0','-1','0','0']" 
												 data-y="['middle','middle','middle','middle']" data-voffset="['-181','-148','-163','-143']" data-fontsize="['16','16','16','14']"
												 data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on"
												 data-frames='[{"from":"y:-50px;opacity:0;","speed":830,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"nothing"}]'
												 data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
												 data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">BOOK VIP NUMBER
											</div>

											<div class="tp-caption Heli-Text-1 text-center tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['1','1','650','650']" 
												 data-y="['middle','middle','top','top']" data-voffset="['17','43','404','404']" data-fontsize="['25','18','18','18']"
												 data-lineheight="['35','30','30','30']" data-fontweight="['300','400','400','400']" data-width="none" data-height="none"
												 data-whitespace="nowrap" data-visibility="['on','on','off','off']" data-type="text" data-responsive_offset="on"
												 data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","speed":1200,"to":"o:1;","delay":1210,"ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
												 data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
												 data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
												 	Because number matters in our digital World...  <br>India's only oldest trusted website - TRUSTED & CERTIFIED COMPANY (SINCE 2001)
											</div>

											<div class="tp-caption heli-button-white rev-btn" data-x="['center','center','center','center']" data-hoffset="['-4','0','0','0']" 
												 data-y="['middle','middle','middle','middle']" data-voffset="['108','135','54','20']" data-width="none" data-height="none"
												 data-whitespace="nowrap" data-type="button"
												 data-actions='[{"event":"click","action":"simplelink","url":"<?php echo e(url('/product-list')); ?>","delay":""}]'
												 data-responsive_offset="on" data-responsive="off"
												 data-frames='[{"from":"y:50px;opacity:0;","speed":570,"to":"o:1;","delay":2070,"ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"to":"auto:auto;","ease":"nothing"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:#2997ff;"}]'
												 data-textAlign="['left','left','left','left']" data-paddingtop="[15,15,15,15]" data-paddingright="[35,35,35,35]"
												 data-paddingbottom="[15,15,15,15]" data-paddingleft="[35,35,35,35]" style="background: none; font-weight: 600; font-size: 16px; color: #2997ff;">Get now >
											</div>

											<div class="tp-caption Heli-Heading-02 tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['0','0','0','1']" 
												 data-y="['middle','middle','middle','middle']" data-voffset="['-91','-60','-60','-76']" data-fontsize="['100','100','70','60']"
												 data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on"
												 data-frames='[{"from":"y:50px;opacity:0;","speed":510,"to":"o:1;","delay":1330,"ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"to":"auto:auto;","ease":"nothing"}]'
												 data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
												 data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">PREMIUM NUMBERS
											</div>
										</li>
										<li data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300" data-rotate="0" data-saveperformance="off" data-title="Slide">

											<!-- MAIN IMAGE -->
											<img src="<?php echo e(asset('/public/front')); ?>/images/slider/banner-3.jpg" alt="" title="" width="1920" height="1000" data-bgposition="center center" data-kenburns="on" data-duration="100000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-blurstart="0" data-blurend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="off" class="rev-slidebg" />

											<!-- LAYERS -->

											<!--<div class="tp-caption Heli-Text-12 tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['0','-1','0','0']" 
												 data-y="['middle','middle','middle','middle']" data-voffset="['-181','-148','-163','-143']" data-fontsize="['16','16','16','14']"
												 data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on"
												 data-frames='[{"from":"y:-50px;opacity:0;","speed":830,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"nothing"}]'
												 data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
												 data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">BOOK VIP NUMBER
											</div>

											<div class="tp-caption Heli-Text-1 text-center tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['1','1','650','650']" 
												 data-y="['middle','middle','top','top']" data-voffset="['17','43','404','404']" data-fontsize="['25','18','18','18']"
												 data-lineheight="['35','30','30','30']" data-fontweight="['300','400','400','400']" data-width="none" data-height="none"
												 data-whitespace="nowrap" data-visibility="['on','on','off','off']" data-type="text" data-responsive_offset="on"
												 data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","speed":1200,"to":"o:1;","delay":1210,"ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
												 data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
												 data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
												 	Lorem Ipsum is simply dummy text of the printing and typesetting industry. <br> Lorem Ipsum has been the industry's standard dummy texT
											</div>

											<div class="tp-caption heli-button-white rev-btn" data-x="['center','center','center','center']" data-hoffset="['-4','0','0','0']" 
												 data-y="['middle','middle','middle','middle']" data-voffset="['108','135','54','20']" data-width="none" data-height="none"
												 data-whitespace="nowrap" data-type="button"
												 data-actions='[{"event":"click","action":"simplelink","target":"_blank","url":"#","delay":""}]'
												 data-responsive_offset="on" data-responsive="off"
												 data-frames='[{"from":"y:50px;opacity:0;","speed":570,"to":"o:1;","delay":2070,"ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"to":"auto:auto;","ease":"nothing"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(34,34,34,1);"}]' data-textAlign="['left','left','left','left']"
												 data-paddingtop="[15,15,15,15]" data-paddingright="[35,35,35,35]" data-paddingbottom="[15,15,15,15]" data-paddingleft="[35,35,35,35]">
												 	SEE MORE 
											</div>

											<div class="tp-caption Heli-Heading-02 tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
												 data-y="['middle','middle','middle','middle']" data-voffset="['-91','-60','-60','-72']" data-fontsize="['100','100','100','60']"
												 data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on"
												 data-frames='[{"from":"y:50px;opacity:0;","speed":510,"to":"o:1;","delay":1330,"ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"to":"auto:auto;","ease":"nothing"}]'
												 data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
												 data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">HEADING HERE 
											</div>-->
										</li>

										<!-- SLIDE  -->
									<li data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300" data-rotate="0" data-saveperformance="off" data-title="Slide">

											
											<img src="<?php echo e(asset('/public/front')); ?>/images/slider/banner-2.jpg" alt="" title="" width="1920" height="1000" data-bgposition="center center" data-kenburns="on" data-duration="100000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-blurstart="0" data-blurend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="off" class="rev-slidebg" />

											<!--<div class="tp-caption Heli-Text-12 tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['0','-1','0','0']" 
												 data-y="['middle','middle','middle','middle']" data-voffset="['-181','-148','-163','-143']" data-fontsize="['16','16','16','14']"
												 data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on"
												 data-frames='[{"from":"y:-50px;opacity:0;","speed":830,"to":"o:1;","delay":500,"ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"nothing"}]'
												 data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
												 data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">BOOK VIP NUMBER
											</div>

											<div class="tp-caption Heli-Text-1 text-center tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['1','1','650','650']" 
												 data-y="['middle','middle','top','top']" data-voffset="['17','43','404','404']" data-fontsize="['25','18','18','18']"
												 data-lineheight="['35','30','30','30']" data-fontweight="['300','400','400','400']" data-width="none" data-height="none"
												 data-whitespace="nowrap" data-visibility="['on','on','off','off']" data-type="text" data-responsive_offset="on"
												 data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","speed":1200,"to":"o:1;","delay":1210,"ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
												 data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
												 data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
												 	Lorem Ipsum is simply dummy text of the printing and typesetting industry. <br> Lorem Ipsum has been the industry's standard dummy texT
											</div>

											<div class="tp-caption heli-button-white rev-btn" data-x="['center','center','center','center']" data-hoffset="['-4','0','0','0']" 
												 data-y="['middle','middle','middle','middle']" data-voffset="['108','135','54','20']" data-width="none" data-height="none"
												 data-whitespace="nowrap" data-type="button"
												 data-actions='[{"event":"click","action":"simplelink","target":"_blank","url":"#","delay":""}]'
												 data-responsive_offset="on" data-responsive="off"
												 data-frames='[{"from":"y:50px;opacity:0;","speed":570,"to":"o:1;","delay":2070,"ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"to":"auto:auto;","ease":"nothing"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(34,34,34,1);"}]' data-textAlign="['left','left','left','left']"
												 data-paddingtop="[15,15,15,15]" data-paddingright="[35,35,35,35]" data-paddingbottom="[15,15,15,15]" data-paddingleft="[35,35,35,35]">
												 	SEE MORE 
											</div>

											<div class="tp-caption Heli-Heading-02 tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
												 data-y="['middle','middle','middle','middle']" data-voffset="['-91','-60','-60','-72']" data-fontsize="['100','100','100','60']"
												 data-width="none" data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on"
												 data-frames='[{"from":"y:50px;opacity:0;","speed":510,"to":"o:1;","delay":1330,"ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"to":"auto:auto;","ease":"nothing"}]'
												 data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]"
												 data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">HEADING HERE 
											</div>-->
										</li>
									</ul>
								</div>
                        </div>
                    </div>
                </div>
                <div class="section pt-8 pb-4">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="text-center">
                                    <h1 class="section-title-bold mb-0">FANCY A NUMBER?</h1>
                                    <h2 class="section-title fz-16 fw-normal ls-16 mb-2">CUSTOMIZE MOBILE NUMBER SERVICE</h2>
                                    <div class="heli-typed-words mt-2 wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.8s">
                                        All our VIP and Fancy Your Choice number is pre meandering indiscriminately, and port empowered in the whole way across 
                                        <div class="dh-typed-text-wrap">
                                            <div id="typed-strings" class="typed-words">
                                                <p>India</p>
                                                <p>City</p>
                                                <p>Area</p>
                                            </div>
                                            <span id="typed"></span>
                                            design
                                        </div>
                                        with the best quality client administrations and moderate rate. <br>Your Mobile Number is your personality. It might show your extravagance status and marking. Branding doesn't come at a moderate rate. In any case, we at book VIP number help you with this to keep up your marking and lavish status by giving a broad scope of Fancy numbers and your decision number that absolutely suits your image, corporates, and individual character with the amazing modest rate.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section pt-10" style="position: relative;">
                    <video width="100%" autoplay loop muted>
                      <source src="<?php echo e(asset('/public/front')); ?>/images/motion-v.mp4" type="video/mp4">
                    </video>
                    <video width="100%" autoplay loop muted class="m-10010">
                      <source src="<?php echo e(asset('/public/front')); ?>/images/motion-v.mp4" type="video/mp4">
                    </video>
                    <video width="100%" autoplay loop muted class="desktop-none" style="margin-top: -10px;">
                      <source src="<?php echo e(asset('/public/front')); ?>/images/motion-v.mp4" type="video/mp4">
                    </video>
                    <video width="100%" autoplay loop muted class="desktop-none" style="margin-top: -10px;">
                      <source src="<?php echo e(asset('/public/front')); ?>/images/motion-v.mp4" type="video/mp4">
                    </video>
                    <video width="100%" autoplay loop muted class="desktop-none" style="margin-top: -10px;">
                      <source src="<?php echo e(asset('/public/front')); ?>/images/motion-v.mp4" type="video/mp4">
                    </video>
                    <video width="100%" autoplay loop muted class="desktop-none" style="margin-top: -10px;">
                      <source src="<?php echo e(asset('/public/front')); ?>/images/motion-v.mp4" type="video/mp4">
                    </video>
                    <video width="100%" autoplay loop muted class="desktop-none" style="margin-top: -10px;">
                      <source src="<?php echo e(asset('/public/front')); ?>/images/motion-v.mp4" type="video/mp4">
                    </video>
                    <div class="container-fluid top-pp">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="text-center">
                                    <h1 class="section-title-bold mb-0" style="color: #fff;">VIP NUMBER</h1>
                                    <h2 class="section-title fz-16 fw-normal ls-16 mb-8" style="color: #fff;">BOOK VIP NUMBER</h2>
                                </div>                                
                            </div>
                        </div>
                        <div class="row">  
                        <?php if($product): ?>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                            <div class="col-md-3 col-6 mbp-8 mb-3 wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.5s">
                                <div class="item-div">
                                    <img src="<?php echo e(asset('/public/front')); ?>/images/back-11.png" class="img-fluid">
                                    <div class="content-box text-center">
                                        <div class="content-box-1">
                                            <h2><?php echo e($allproduct->productnumber); ?></h2>
                                            <p><b>Price:</b> <i class="fa fa-inr"></i><b><?php echo e($allproduct->price); ?>/-</b></p>
                                        </div>
                                        <div class="row pt-4 item-divrow">
                                            <div class="col-sm-6 col-6 mbp-0 text-center">
                                                <a href="<?php echo e(url('/cart/addtoCart')); ?>/<?php echo e($allproduct->id); ?>" class="btn btn-rounded btn-bg-dark">Add to Card</a>
                                            </div>
                                            <div class="col-sm-6 col-6 mbp-0 text-center">
                                                <a href="#" class="btn btn-rounded btn-bg-dark" onclick="buynow(<?php echo e($allproduct->id); ?>)" ><span>Buy Now</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>         
                            
                            
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="mt-4 text-center">
                                    <a href="<?php echo e(url('/product-list')); ?>" class="btn rounded mt-3 btn-bg-dark"><span>VIEW MORE</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--<video autoplay muted loop style="width: 100%;">
                    <source src="<?php echo e(asset('/public/front')); ?>/images/banner-video.mp4" type="video/mp4"> Your browser does not support the video tag.
                </video>-->
                <div class="section mt-5 mb-3">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-4 pb-3">
                                <div class="feature-item style-3 text-center wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.5s">
                                    <a href="<?php echo e(url('/product-list')); ?>">
                                        <div class="content">
                                        <div class="feature-icon">
                                            <img src="<?php echo e(asset('/public/front')); ?>/images/number01.png">
                                        </div>
                                        <h3>Numerology Numbers</h3>
                                        <div class="desc">
                                            Contact us to get your lucky stars in your luck.
                                        </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 pb-3">
                                <div class="feature-item style-3 text-center wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s">
                                    <a href="<?php echo e(url('/product-list')); ?>">
                                    <div class="content">
                                        <div class="feature-icon">
                                            <img src="<?php echo e(asset('/public/front')); ?>/images/number02.png">
                                        </div>
                                        <h3>Birthday Date</h3>
                                        <div class="desc">
                                            You can get your Birthday Date Phone number.
                                        </div>
                                    </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 pb-3">
                                <div class="feature-item style-3 text-center wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.5s">
                                    <a href="<?php echo e(url('/product-list')); ?>"><div class="content">
                                        <div class="feature-icon">
                                            <img src="<?php echo e(asset('/public/front')); ?>/images/number02.png">
                                        </div>
                                        <h3>Lucky Number</h3>
                                        <div class="desc">
                                            Do you also have a lucky number? Get it now in the form of a VIP Phone Number.
                                        </div>
                                    </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 pb-3">
                                <div class="feature-item style-3 text-center wow fadeInUp" data-wow-duration="3s" data-wow-delay="0.6s">
                                    <a href="<?php echo e(url('/product-list')); ?>">
                                    <div class="content">
                                        <div class="feature-icon">
                                            <img src="<?php echo e(asset('/public/front')); ?>/images/number04.png">
                                        </div>
                                        <h3>Area Pincode Number</h3>
                                        <div class="desc">
                                            Buy VIP Number, Building, or Street Number.
                                        </div>
                                    </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 pb-3">
                                <div class="feature-item style-3 text-center wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.5s">
                                    <a href="<?php echo e(url('/product-list')); ?>">
                                    <div class="content">
                                        <div class="feature-icon">
                                            <img src="<?php echo e(asset('/public/front')); ?>/images/number05.png">
                                        </div>
                                        <h3>Car Number</h3>
                                        <div class="desc">
                                            Get your car number in your phone number.
                                        </div>
                                    </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 pb-3">
                                <div class="feature-item style-3 text-center wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.3s">
                                    <a href="<?php echo e(url('/product-list')); ?>">
                                        <div class="content">
                                        <div class="feature-icon">
                                            <img src="<?php echo e(asset('/public/front')); ?>/images/number06.png">
                                        </div>
                                        <h3>Similar Number</h3>
                                        <div class="desc">
                                            You can get your favorite numbers in your phone number.Select your ideal portable number. The one you like and which suits your character. 
                                        </div>
                                    </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section section-cover section-bg-50 pt-10 pb-10">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-5 wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.5s">
                                <h2 class="fz-30 mb-3 c-fff">BOOK VIP NUMBER<br /><b>AGENCY</b></h2>
                                <p class="c-fff">All our VIP and Fancy Your Choice number is pre meandering indiscriminately, and port empowered in the whole way across India with the best quality client administrations and moderate rate. </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section section-cover section-bg-52 pt-10 pb-10">
                    <div class="bg-overlay-white"></div>
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 col-md-6 wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.5s">
                                <h2 class="section-title pt-3 mb-2"><b>WHAT</b>PEOPLESAY</h2>
                                <p>
                                    Buy Premium and Fancy Numbers form Book VIP Number and Get Amazingly Fast And Promising Service As Per Talk.
                                </p>
                            </div>
                            <div class="col-sm-12 col-lg-6 col-md-6 offset-xs-1 col-xs-10 wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.5s">
                                <div class="mb-5 d-block d-md-block d-lg-none"></div>
                                <div class="testimonial-carousel dots-carousel">
                                    <div class="item">
                                        <div class="quote bg-dark">
                                            Trustworthy And Good Customer Service When I Bought VIP Mobile Number From Book Vip Number, Also Good Feedback Services All Is Easy. Thank You!
                                        </div>
                                        <div class="author">
                                            <span class="dark">Anamika Mishra</span>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="quote bg-dark">
                                            I have booked my Number from Book VIP Number. They Delivered the Number I wanted as soon as I made the payment.
                                        </div>
                                        <div class="author">
                                            <span class="dark">Ankit Kumar</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section section-bg-6 section-cover pt-7 pb-7">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-5 wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.5s">
                                <h2 class="section-title fz-16 fw-normal ls-16 mt-3 white">KEEP IN TOUCH</h2>
                                <h2 class="section-title white fz-50 ls-0 lh-75 mb-4"><b>FOLLOW US</b></h2>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="fz-18 white fw-800 uppercase mb-2"><i class="fa fa-facebook"></i> <a class="white" href="#" target="_blank">FACEBOOK</a></div>
                                        <div class="fz-18 white fw-800 uppercase mb-2"><i class="fa fa-pinterest"></i> <a class="white" href="#" target="_blank">PINTEREST</a></div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="fz-18 white fw-800 uppercase mb-2"><i class="fa fa-twitter"></i> <a class="white" href="#" target="_blank">TWITTER</a></div>
                                        <div class="fz-18 white fw-800 uppercase mb-2"><i class="fa fa-instagram"></i> <a class="white" href="#" target="_blank">INSTAGRAM</a></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-7 padding-left-lg-50">
                                <div class="mt-5 d-block d-lg-none d-xl-none"></div>
                                <h1 class="section-title-bold fz-36 mb-3 ls-5" style="color: #fff;">DROP A LINE</h1>
                                <form class="black">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <input type="text" name="your-name" value="" size="40" class="form-control" placeholder="Your name here" />
                                        </div>
                                        <div class="col-md-6">
                                            <input type="email" name="your-email" value="" size="40" class="form-control" placeholder="Your email" />
                                        </div>
                                        <div class="col-md-12">
                                            <input type="text" name="your-subject" value="" size="40" class="form-control" placeholder="Subject" />
                                        </div>
                                        <div class="col-md-12">
                                            <textarea name="your-message" cols="20" rows="5" class="form-control" placeholder="Your message"></textarea>
                                        </div>
                                        <div class="col-md-12">
                                            <input type="submit" value="Send Message" class="form-submit" />
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!--<div class="section pt-4 pb-4">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="client-carousel drag-carousel" data-auto-play="true" data-desktop="6" data-laptop="4" data-tablet="3" data-mobile="1">
                                    <div class="item text-center">
                                        <img src="<?php echo e(asset('/public/front')); ?>/images/client/client_1.png" alt="" />
                                        <div class="overlay-wrapper">
                                            <div class="overlay"></div>
                                            <div class="text">
                                                <div class="text-inner">Client 01</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item text-center">
                                        <img src="<?php echo e(asset('/public/front')); ?>/images/client/client_2.png" alt="" />
                                        <div class="overlay-wrapper">
                                            <div class="overlay"></div>
                                            <div class="text">
                                                <div class="text-inner">Client 02</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item text-center">
                                        <img src="<?php echo e(asset('/public/front')); ?>/images/client/client_3.png" alt="" />
                                        <div class="overlay-wrapper">
                                            <div class="overlay"></div>
                                            <div class="text">
                                                <div class="text-inner">Client 03</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item text-center">
                                        <img src="<?php echo e(asset('/public/front')); ?>/images/client/client_4.png" alt="" />
                                        <div class="overlay-wrapper">
                                            <div class="overlay"></div>
                                            <div class="text">
                                                <div class="text-inner">Client 04</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item text-center">
                                        <img src="<?php echo e(asset('/public/front')); ?>/images/client/client_5.png" alt="" />
                                        <div class="overlay-wrapper">
                                            <div class="overlay"></div>
                                            <div class="text">
                                                <div class="text-inner">Client 05</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item text-center">
                                        <img src="<?php echo e(asset('/public/front')); ?>/images/client/client_6.png" alt="" />
                                        <div class="overlay-wrapper">
                                            <div class="overlay"></div>
                                            <div class="text">
                                                <div class="text-inner">Client 06</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item text-center">
                                        <img src="<?php echo e(asset('/public/front')); ?>/images/client/client_7.png" alt="" />
                                        <div class="overlay-wrapper">
                                            <div class="overlay"></div>
                                            <div class="text">
                                                <div class="text-inner">Client 07</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>-->
            </div>
<script>
    buynow = (id) => {
        <?php if(Session()->has('logged_user') || Session()->has('logged_buyer')): ?>
        //alert(id);
        document.location.href="<?php echo e(url('/cart/BuytoCart')); ?>/"+id;
        <?php else: ?>
        document.location.href="<?php echo e(url('/login')); ?>";
        <?php endif; ?>
    }
</script>        
          <?php $__env->stopSection(); ?>

 
<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\bookvipnumber\resources\views/front/index.blade.php ENDPATH**/ ?>