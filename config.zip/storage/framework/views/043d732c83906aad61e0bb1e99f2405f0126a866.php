 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Daily Buy Report</h1>
                </div>
                <?php if($success=Session::get('success')): ?>
                <div class="alert alert-success"><?php echo e($success); ?></div>
                <?php endif; ?>
              
            </div>
        </div>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-default">
            <div class="alert alert-warning"><b>Daily Buy Report</b></div>
                <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Vendor Name</th>
                                <th>Today Sale</th>
                                <th>Total Sale</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                            $srn=1;
                        ?>
                           <?php if($dailysale): ?>
                                
                                 <?php $__currentLoopData = $dailysale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allsale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($srn); ?></td>
                                <td>
                                
                               <?php $vendor=App\commonmodel::findbuyer($allsale->user_id); ?>
                               <?php if(!empty($vendor)): ?><?php echo e($vendor->name); ?> (<?php echo e($vendor->email); ?>)<?php endif; ?>
                                </td>
                                <td> <?php $todaysale=App\commonmodel::todaybuy($allsale->user_id); ?> <?php echo e($todaysale); ?></td>
                                <td> <?php echo e($allsale->total); ?></td>
                                
                                
                            </tr>
                            <?php $srn++ ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                           <?php endif; ?>
                            
                           
                            
                            

                        </tbody>
                        <tfoot>
                            <tr>
                                 <th>S.No.</th>
                                <th>Vendor Name</th>
                                <th>Today Sale</th>
                                <th>Total Sale</th>   
                            </tr>
                        </tfoot>


                    </table>

                  
                    
                </div>

            </div>

        </div>
    </section>

</div>
<?php $__env->startSection('script'); ?>

<!-- page script -->
<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });
    $(document).ready(function() {
        $('#example1').DataTable();
        $('#example2').DataTable();
    });
</script>

   
 
<?php $__env->stopSection(); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/develsi8/public_html/laravel/resources/views/admin/vendor/dailybuy.blade.php ENDPATH**/ ?>