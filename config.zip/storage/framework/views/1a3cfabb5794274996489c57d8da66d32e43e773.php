<style>
    body {font-family:Helvetica, Arial, sans-serif; font-size:10pt;} 
    table {width:40%; border-collapse:collapse; border:1px solid #CCC;}
    td {padding:5px; border:1px solid #CCC; border-width:1px 0;}
    .inner{
        width:40%;border:groove;
    }
</style>

<body>
<div class="inner">
             <table align="center" border="1" width="100%">
         <tr>
         <td style="text-align:center; border:1px #CCCCCC solid;">Activation Link</td>
         <td style="text-align:center; border:1px #CCCCCC solid;"><a href="<?php echo e(url('/verifiedemail')); ?>/<?php echo e($dataset['id']); ?>">Click Here to Activate Email Account</a></td> 
        </tr>         
      </table>
  </div>
    </body>






<?php /**PATH C:\xampp\htdocs\laravel_test\resources\views/front/sendmail/regmail.blade.php ENDPATH**/ ?>