 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<style>
.content-header .breadcrumb {
margin-left: 20px;
}
</style>
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<div class="content-header">
<div class="container-fluid">
<div class="row mb-2">
    <div class="col-sm-6">
        <h1 class="m-0">Manage Discount Coupon</h1>
    </div>
    <!-- /.col -->
    <!-- /.col -->
</div>
<!-- /.row -->
</div>
<!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<!-- Main content -->
<div class="content">
<div class="container-fluid">
<div class="row">
    <div class="col-lg-12">
        <div class="card">
                <div class="card-body">
                <!--<form name="sortbyfrm" id="sortbyfrm" method="get" action="<?php echo e(url('seller/managecoupon')); ?>">
                <div class="row">
                <div class="col-sm-4 sortby">
                </div>
                <div class="col-sm-4 date-pickme">
                </div>
                <div class="col-sm-3 search-ord">
                <input type="text" id="keyword" name="keyword" class="form-control" placeholder="Search..">
                </div>
                <div class="col-sm-1">
                <button type="submit" class="btn btn-block btn-primary">Go!</button>
                </div>
                </div>
                </form>--><br>
                <div class="">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Name</th>
                                <th>Code</th>
                                <th>Percent</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $srn=1;
                            ?>
                            <?php if($coupon): ?>
                            <?php $__currentLoopData = $coupon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allcoupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($srn); ?></td>
                                <td><?php echo e($allcoupon->name); ?></td>
                                <td><?php echo e($allcoupon->code); ?></td>
                                <td><?php echo e($allcoupon->percent); ?></td>
                                <td><?php echo e($allcoupon->start_date); ?></td>
                                <td><?php echo e($allcoupon->end_date); ?></td>
                            </tr>
                            <?php $srn++ ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                    <div class="d-flex justify-content-center">
                    <?php echo $coupon->links(); ?>

                    </div>
                </div>
                
            </div>
            <!-- /.card-body -->
        </div>
    </div>
</div>
</div>
<!-- /.row -->
</div>
<!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/emporiumstoreco/public_html/resources/views/seller/coupon/manage_coupon.blade.php ENDPATH**/ ?>