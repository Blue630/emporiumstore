<!DOCTYPE html>
<html lang="en">
<head>
 <?php echo $__env->make('vendor.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->yieldContent('head'); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">

<div class="wrapper">
<?php echo $__env->make('vendor.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->yieldContent('header'); ?>
  <!-- <div class="content-wrapper"> -->
   <?php echo $__env->yieldContent('content'); ?>
  
 
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
    <?php echo $__env->make('vendor.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->yieldContent('footer'); ?>
  <!-- Main Footer -->
</div>
<!-- ./wrapper -->


<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<?php echo $__env->make('vendor.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('script'); ?>

</body>
</html>
<?php /**PATH E:\xampp\htdocs\bookvipnumber\resources\views/vendor/layout/layout.blade.php ENDPATH**/ ?>