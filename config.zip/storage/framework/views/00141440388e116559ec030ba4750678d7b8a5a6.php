<footer class="main-footer text-center">
    <strong>Copyright &copy; 2020 <a href="#">Book VIP Number</a>.</strong>
    All rights reserved.
  </footer>
   <!-- The Modal -->
    <div class="modal" id="myModal">
      <div class="modal-dialog">
        <div class="modal-content">
    
          <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">Add Distributor</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <!-- Modal body -->
          <div class="modal-body">
            <form action="">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Enter Name">
              </div>
              <div class="form-group">
                <input type="email" class="form-control" placeholder="Enter Email">
              </div>
              <div class="form-group">
                <input type="number" class="form-control" placeholder="Enter Phone">
              </div>
              <div class="form-group">
                <input type="password" class="form-control" placeholder="Enter Password">
              </div>
              <div class="form-group">
                <input type="password" class="form-control" placeholder="Enter Confirm Password">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Enter Store Name">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Enter Address">
              </div>
              <div class="form-group">
                <input type="file" class="form-control" placeholder="Enter Aadhar Card">
              </div>
              <div class="form-group">
                <input type="file" class="form-control" placeholder="Enter Pan Card">
              </div>
              
              <button type="submit" class="btn btn-primary">Submit</button>
            </form>
          </div>
        </div>
      </div>
    </div><?php /**PATH /home/w9wyzh39hnz2/public_html/resources/views/admin/includes/footer.blade.php ENDPATH**/ ?>