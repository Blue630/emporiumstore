<header class="header">
    <div class="header-top bg-theme-colored sm-text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-6 pt-30 pb-20">
                    <div class="widget no-border m-0">
                        <img src="<?php echo e(asset('/public/front')); ?>/images/logo.png" alt="" />
                    </div>
                </div>
                <div class="col-md-6 pt-20 pb-20">
                    <div class="widget no-border m-0">
                        <ul class="list-inline pull-right flip sm-pull-none sm-text-center mt-5">
                            <li class="mt-sm-10 mb-sm-10">
                                <!-- <a class="btn btn-default btn-flat btn-xs p-5 font-11 pl-10 text-uppercase pr-10 ajaxload-popup" href="<?php echo e(url('/donoatenow')); ?>"><span>Donate Now</span></a> -->
                                
                                <button class="btn btn-default btn-flat btn-xs p-5 font-11 pl-10 text-uppercase pr-10" data-toggle="modal" data-target="#myModal"><span>Donate Now</span></button>
                                
                            </li>
                            <li class="mt-sm-10 mb-sm-10">
                            <?php if(session()->has('logged_user')): ?>
                            <a class="btn btn-default btn-flat btn-xs p-5 font-11 pl-10 text-uppercase pr-10" href="<?php echo e(url('/userlogout')); ?>"><span>Logout</span></a>
                            
                                <?php else: ?>
                                <a class="btn btn-default btn-flat btn-xs p-5 font-11 pl-10 text-uppercase pr-10" href="<?php echo e(url('/userlogin')); ?>"><span>Login/Register</span></a>
                                <?php endif; ?>
                            </li>
                            <li class="mt-sm-10 mb-sm-10">
                                <a class="btn btn-default btn-flat btn-xs p-5 font-11 pl-10 text-uppercase pr-10" href="#" onclick="return onlinhealth(199);"><span>Healthcare</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-nav">
        <div class="header-nav-wrapper navbar-scrolltofixed" style="background: #000;">
            <div class="container">
                <nav id="menuzord-right" class="menuzord default no-bg">
                    <!-- <a class="menuzord-brand pull-left flip" href="index.php"><img src="images/logo.png" alt="" /></a> -->
                    <ul class="menuzord-menu">
                        <li class="">
                            <a href="<?php echo e(url('/')); ?>">Home</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/about')); ?>">About Us</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/become-a-volunteer')); ?>">Volunteer</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/need-help')); ?>">Need Help</a>
                        </li>
                        <li><a href="#">Our Mission</a>
                            <ul class="dropdown">
                              <li><a href="#">Mission Healthcare</a>
                                <ul class="dropdown">
                                    <li><a href="<?php echo e(url('/online-consulting')); ?>">Online Consulting</a></li>
                                    <li><a href="<?php if(session()->has('logged_user') && ($ehrform)>0): ?><?php echo e(url('/ehr')); ?> <?php elseif(session()->has('logged_user') && ($ehrform)==0): ?> <?php echo e(url('/create-ehr')); ?>/<?php echo e(session()->get('logged_user')->id); ?> <?php else: ?> <?php echo e(url('/userlogin')); ?><?php endif; ?>">EHR</a></li>
                                    <li><a href="<?php echo e(url('/our-product')); ?>">Our Product</a></li>
                                    <li><a href="<?php echo e(url('/healthcare')); ?>">Healthcare</a></li>
                                </ul>
                              </li>
                              <li><a href="<?php echo e(url('/mission-education')); ?>">Mission Education</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/contact')); ?>">Contact Us</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header><?php /**PATH E:\xampp\htdocs\ensurecare\resources\views/front/include/header.blade.php ENDPATH**/ ?>