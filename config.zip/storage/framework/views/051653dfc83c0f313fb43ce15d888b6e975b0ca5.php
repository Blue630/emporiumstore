    <?php $__env->startSection('content'); ?>
            <div id="main">
                <div class="section section-bg-53 section-cover pt-10 pb-10">
                    <div class="bg-overlay"></div>
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="text-center">
                                    <h2 class="fz-70 white"><b>CART</b></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section pb-6 pt-6">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <table class="table shop-cart">
                                    <thead>
                                        <tr>
                                            <th class="product-remove">&nbsp;</th>
                                            <th class="product-thumbnail">Product</th>
                                            <th class="product-name">Price</th>
                                            <th class="product-subtotal">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="cart_item">
                                            <td class="product-remove">
                                                <a href="#" class="remove">&times;</a>
                                            </td>
                                            <td class="product-name" data-title="Product">
                                                <a href="#">9854898541</a>
                                            </td>
                                            <td class="product-price" data-title="Price">
                                                <span class="amount"><i class="fa fa-inr"></i>35.00</span>
                                            </td>
                                            <td class="product-subtotal" data-title="SubTotal">
                                                <span class="amount"><i class="fa fa-inr"></i>35.00</span>
                                            </td>
                                        </tr>
                                        <tr class="cart_item">
                                            <td class="product-remove">
                                                <a href="#" class="remove">&times;</a>
                                            </td>
                                            <td class="product-name" data-title="Product">
                                                <a href="#">9854898541</a>
                                            </td>
                                            <td class="product-price" data-title="Price">
                                                <span class="amount"><i class="fa fa-inr"></i>35.00</span>
                                            </td>
                                            <td class="product-subtotal" data-title="SubTotal">
                                                <span class="amount"><i class="fa fa-inr"></i>35.00</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="6" class="actions">
                                                <div class="coupon">
                                                    <input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="Coupon code" />
                                                    <input type="submit" class="btn btn-rounded btn-dark" name="apply_coupon" value="Apply Coupon" />
                                                </div>
                                                <input type="submit" class="btn btn-rounded btn-bg-dark update-cart" name="update_cart" value="Update Cart" />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="cart-totals">
                                    <h2 class="wg-title">Cart Totals</h2>
                                    <table>
                                        <tbody>
                                            <tr class="cart-subtotal">
                                                <th>Subtotal</th>
                                                <td><i class="fa fa-inr"></i>116.00</td>
                                            </tr>
                                            <tr class="shipping">
                                                <th>Shipping</th>
                                                <td>Free Shipping</td>
                                            </tr>
                                            <tr class="order-total">
                                                <th>Total</th>
                                                <td><strong><i class="fa fa-inr"></i>146.00</strong></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <div class="proceed-to-checkout">
                                        <a href="#" class="btn btn-rounded btn-dark">Proceed to Checkout</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\vip\resources\views//front/cart.blade.php ENDPATH**/ ?>