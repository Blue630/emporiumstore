<footer class="main-footer text-center">
    <strong>Copyright &copy; 2020 <a href="#">Book VIP Number</a>.</strong>
    All rights reserved.
  </footer>
   <?php /**PATH E:\xampp\htdocs\bookvipnumber\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>