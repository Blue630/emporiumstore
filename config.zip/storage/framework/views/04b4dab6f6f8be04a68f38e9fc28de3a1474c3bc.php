
<?php $__env->startSection('content'); ?>
 
<?php
use App\page_content;
?>
 
 <!-- <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script> -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit <?php echo e($contactusdetail->page_name); ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/manage_pages')); ?>" class="btn btn-primary"><i class="fas fa-backward"></i>&nbsp;</i>Back</a></li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <!-- Main content -->   
    <section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">

          <div class="card-body">
            <?php if($msg=Session::get('success')): ?>
            <div class="alert alert-success"><?php echo e($msg); ?></div>
            <?php endif; ?>
           
            <div class="row">
              
              <div class="col-md-12">




 <table id="example1" class="table table-bordered table-striped">
     <thead>
   <tr>
     <th>S.No</th>
     <th>Content</th>
     <th>Action</th>
     </tr>
     </thead>
   <tbody>
    
         <?php 
$contents = page_content::getPageContent($contactusdetail->id);
$i=1;
foreach($contents as $content){
?>
 <tr>
         <td><?php echo e($i); ?></td>
         <td><?php echo e($content->heading); ?></td>
         <td><a href="<?php echo e(url('/admin/edit_content')); ?>/<?php echo e($content->id); ?>">Edit</a></td>
          </tr>
         <?php
$i++;
}
?>
    
   </tbody>
     
 </table>

              </div>

            </div>
          
           
          </div>

        </div>

      </div>
    </section>

  </div>
<script>
CKEDITOR.replace( 'description' );
CKEDITOR.replace( 'description2' );
CKEDITOR.replace( 'description3' );
</script>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/develsi8/public_html/emporium/resources/views//admin/pages/edit_contactus.blade.php ENDPATH**/ ?>