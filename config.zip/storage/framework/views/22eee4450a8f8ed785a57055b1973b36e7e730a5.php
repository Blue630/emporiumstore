
 <?php $__env->startSection('content'); ?>
 
<?php
use App\Specification;
?>
 
 <!-- <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script> -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Option</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/manage_option')); ?>" class="btn btn-primary"><i class="fas fa-backward"></i>&nbsp;</i>Back</a></li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">

          <div class="card-body">
            <?php
            if($errors->first('option')!="")
            {
            ?>
            <div class="alert alert-danger"><?php echo e($errors->first('option')); ?></div>
            <?php
            }
            ?>
            <?php if($msg=Session::get('success')): ?>
            <div class="alert alert-success"><?php echo e($msg); ?></div>
            <?php endif; ?>
            <form method="post" action="<?php echo e(url('admin/edit_option')); ?>/<?php echo e(@$optiondetail->id); ?>" enctype="multipart/form-data" onsubmit="onSubmit()">
              <?php echo csrf_field(); ?>
            <div class="row">
              
              <div class="col-md-12">


                <div class="form-group">
                  <label>Option Name</label>
                  <input type="text" name="option" id="option" class="form-control" value="<?php echo e($optiondetail->name); ?>" required>
                </div>
                
                <div class="form-group">
                  <label>Image</label><br>
                  <?php if($optiondetail->image!="") 
                  { 
                  ?>
                  <img src="<?php echo e(asset('public/option')); ?>/<?php echo e($optiondetail->image); ?>" height="100" width="120" alt="Option Image">
                  <?php
                  }
                  ?>
                  <input type="file" class="form-control" name="image" id="image" value="<?php echo $optiondetail->image;?>"/>
                </div>



                <div class="form-group">
                     <label>Specification</label>
                  <select type="text" name="specs" id="specs" class="form-control" required>
                      
<?php 

$specifications = Specification::getspecifications();
foreach($specifications as $specification){
?>

<option <?php echo ($specification->id == $optiondetail->specs_id ?'selected="selected"':"") ?>  value="<?php echo e($specification->id); ?>"><?php echo e($specification->name); ?></option>
<?php
}
?>
  
                  </select>  
                  <?php echo e($errors->first('name')); ?>

                </div>
              </div>

            </div>
            <div class="">
                  <button type="submit" class="btn_submit btn btn-primary">Submit</button>
                </div>
            </form>
           
          </div>

        </div>

      </div>
    </section>

  </div>
<script>
function onSubmit() {
  $('.btn_submit').attr('disabled', true);
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/emporiumstoreco/public_html/resources/views//admin/option/edit_option.blade.php ENDPATH**/ ?>