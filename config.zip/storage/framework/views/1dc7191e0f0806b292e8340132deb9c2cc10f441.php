<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12">
                <h2><b>Book VIP Number</b></h2>
                <!--<img src="<?php echo e(asset('/public/front')); ?>/images/logo-1.png" alt="" />-->
                <p>Book VIP number’s Team gives solid client care to all the clients since we've earned all the character and trust of our clients. For that, they all merit the best administrations and quality works; this is something that our group accepted. </p>
                <small> <?php if(session()->has('logged_buyer')): ?><a href="<?php echo e(url('/buyerlogout')); ?>" style="color: #06c;">Partner Logout</a><?php else: ?><a href="<?php echo e(url('/buyer-login')); ?>" style="color: #06c;">Partner Login</a> <?php endif; ?> | <a href="<?php echo e(url('/vendor-register')); ?>" style="color: #06c;">Become a Partner</a> Login Panel. </small>
            </div>
            <div class="col-lg-3 col-md-3">
                <h3 class="widget-title uppercase">Quick Links</h3>
                <ul class="menu">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a href="<?php echo e(url('/about-us')); ?>">About Us</a></li>
                    <li><a href="<?php echo e(url('/product-list')); ?>">Number Store</a></li>
                    <li><a href="<?php echo e(url('/contact-us')); ?>">Contact us</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-3">
                <h3 class="widget-title uppercase">Quick Links</h3>
                <ul class="menu">
                    <li><a href="<?php echo e(url('/terms')); ?>">Terms & Conditions</a></li>
                    <li><a href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy</a></li>
                    <li><a href="<?php echo e(url('/faq')); ?>">Faq</a></li>
                    <!--<li><a href="<?php echo e(url('/vendor-register')); ?>">Become a Vendor</a></li>-->
                </ul>
            </div>
        </div>
    </div>
</footer>
<div class="copyright text-center">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <p style="font-size: 14px;">Copyright ©2020. All Rights Reserved <!--| Designed By Webpace India - <a href="https://www.webpaceindia.com/" target="_blank">Website Designing Company in Delhi</a>--></p>
            </div>
        </div>
    </div>
</div>
<div class="whatsapp">
   <a href="tel:+91 9177772222" target="_blank" class="bouncenew"><img src="<?php echo e(asset('/public/front')); ?>/images/call-now.png"></a>
</div><?php /**PATH C:\xampp\htdocs\laravel_test\resources\views/front/include/footer.blade.php ENDPATH**/ ?>