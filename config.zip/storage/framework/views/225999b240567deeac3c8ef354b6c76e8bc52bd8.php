
 <?php $__env->startSection('content'); ?>
 <!-- <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script> -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Category</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/manage_cate')); ?>" class="btn btn-primary"><i class="fas fa-backward"></i>&nbsp;</i>Back</a></li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">

          <div class="card-body">
            <div class="container">
            <?php
            if($errors->first('catname')!="")
            {
            ?>
            <div class="alert alert-danger"><?php echo e($errors->first('catname')); ?></div>
            <?php
            }
            ?>
            </div>
            <?php if($msg=Session::get('success')): ?>
            <div class="alert alert-success"><?php echo e($msg); ?></div>
            <?php endif; ?>
            <form method="post" action="<?php echo e(url('admin/edit_cate')); ?>/<?php echo e(@$catedetail->id); ?>" enctype="multipart/form-data" onsubmit="onSubmit()">
              <?php echo csrf_field(); ?>
            <div class="row">
              
              <div class="col-md-12">

                <div class="form-group">
                  <label>Category</label>
                  <input type="text" name="catname" id="catname" class="form-control" value="<?php if($catedetail): ?><?php echo e($catedetail->catname); ?><?php endif; ?>">
                  <?php echo e($errors->first('catname')); ?>

                </div>

                <div class="form-group">
                  <label>Category Image</label>
                  <?php if($catedetail->categoryimg!="") 
                  { 
                  ?>
                  <img src="<?php echo e(asset('public/category')); ?>/<?php echo e($catedetail->categoryimg); ?>" height="100" width="120" alt="Category Image">
                  <?php
                  }
                  ?>
                  <input type="file" class="form-control" name="categoryimg" id="categoryimg" value="<?php echo $catedetail->categoryimg;?>"/>
                </div>
              </div>

            </div>
            <div class="">
                  <button type="submit" class="btn_submit btn btn-primary">Submit</button>
                </div>
            </form>
           
          </div>

        </div>

      </div>
    </section>

  </div>
<script>
function onSubmit() {
  $('.btn_submit').attr('disabled', true);
}
</script>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/emporiumstoreco/public_html/resources/views//admin/category/edit_cate.blade.php ENDPATH**/ ?>