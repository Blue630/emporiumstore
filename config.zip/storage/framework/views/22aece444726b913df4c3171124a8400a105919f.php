<footer class="main-footer overlay-bg" style="background-image: url((<?php echo e(asset('/public/front')); ?>/images/footer/bg.jpg);">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-md-7 col-sm-4 col-xs-12 footer-column">
                    <div class="logo-widget footer-widget">
                        <div class="footer-logo">
                            <a href="index.php"><img src="<?php echo e(asset('/public/front')); ?>/images/logo/footer-logo.png" alt="" /></a>
                        </div>
                        <div class="text white">Cleanguys is an online Dry-Cleaning and Laundry services Near Me made by a gathering of classy people with a dream to pioneer laundry administration in India, through an attention on quality, trust, individual duty, and predominant client support. We give you the best Online Dry-Cleaning and Laundry services with moderate estimating.</div>  
                        <p>&nbsp;</p>
                        <ul class="footer-social in-block">
                            <li>
                                <a href="#"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-rss"></i></a>
                            </li>
                        </ul>
                        
                    </div>
                </div>
                <!--<div class="col-md-3 col-sm-4 col-xs-12 footer-column">
                    <div class="service-widget footer-widget">
                        <div class="footer-title"><h4>Services</h4></div>
                        <ul class="list">
                            <li><a href="index.php">- &nbsp;Home</a></li>
                            <li><a href="about">- &nbsp;About Us</a></li>
                            <li><a href="#services">- &nbsp;Services</a></li>
                            <li><a href="#testimonials">- &nbsp;Testimonials</a></li>
                            <li><a href="#contact">- &nbsp;Our Plan</a></li>
                        </ul>
                    </div>
                </div>-->
                <div class="col-md-5 col-sm-4 col-xs-12 footer-column">
                    <div class="logo-widget footer-widget">
                        <div class="footer-title"><h4>Contact Us</h4></div>
                        <div class="location-box">
                            <div class="icon-box"><i class="fa fa-map-marker"></i></div>
                            <div class="text white">
                                65, Old Anarkali, Krishna Nagar, Delhi-51
                            </div>
                        </div>
                        <div class="location-box">
                            <div class="icon-box"><i class="fa fa-map-marker"></i></div>
                            <div class="text white">
                                Flat No. 1103, Coral-A, Shalimar city, Delhi, Wazirabad Road, Sahibabad, Ghaziabad, UP-201005  
                            </div>
                        </div>
                        <div class="location-box">
                            <div class="icon-box"><i class="fa fa-phone"></i></div>
                            <div class="text white">
                                +91 9311460089, +91 9311460059
                            </div>
                        </div>
                        <div class="location-box">
                            <div class="icon-box"><i class="fa fa-envelope"></i></div>
                            <div class="text white"> 
                                 info@cleanguys.com
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom centred">
        <div class="container">
            <div class="container">
                <div class="copyright">Copyright ©2020. All Rights Reserved | Designed By <a href="https://www.webpaceindia.com/" target="_blank">Website Designing Company in Delhi</a></div>
            </div>
        </div>
    </div>
    <div class="bubbleContainer">
        <div class="bubble-1"></div>
        <div class="bubble-2"></div>
        <div class="bubble-3"></div>
        <div class="bubble-4"></div>
        <div class="bubble-5"></div>
        <div class="bubble-6"></div>
        <div class="bubble-7"></div>
        <div class="bubble-8"></div>
        <div class="bubble-9"></div>
        <div class="bubble-10"></div>
        <div class="bubble-11"></div>
        <div class="bubble-12"></div>
        <div class="bubble-13"></div>
        <div class="bubble-14"></div>
        <div class="bubble-15"></div>
    </div>
</footer><?php /**PATH E:\xampp\htdocs\clean-guys\resources\views/front/include/footer.blade.php ENDPATH**/ ?>