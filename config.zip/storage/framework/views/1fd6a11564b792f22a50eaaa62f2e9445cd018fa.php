<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.5s">
                <img src="<?php echo e(asset('/public/front')); ?>/images/footer-logo.png" alt="Heli" />
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                proident.</p>
            </div>
            <div class="col-lg-2 col-md-6 wow bounce" data-wow-duration="2s" data-wow-delay="0.5s">
                <h3 class="widget-title uppercase">Company</h3>
                <ul class="menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="faq.php">FAQ</a></li>
                    <li><a href="contact-us.php">Contact us</a></li>
                </ul>
                <div class="mb-5 d-block d-md-block d-lg-none"></div>
            </div>
            <div class="col-lg-3 col-md-6 wow bounce" data-wow-duration="2s" data-wow-delay="0.5s">
                <h3 class="widget-title uppercase">Contact Us</h3>
                <div class="office">
                    <p><i class="pe-7s-call"></i> +91 987654321</p>
                    <p><i class="pe-7s-mail-open-file"></i> Demo@gmail.com</p>
                    <p><i class="pe-7s-map-2"></i> New Delhi, India 110001</p>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="copyright text-center">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">Copyright ©2020. All Rights Reserved | Designed By <a href="https://www.webpaceindia.com/" target="_blank">Website Designing Company in Delhi</a></div>
        </div>
    </div>
</div><?php /**PATH E:\xampp\htdocs\vip\resources\views/front/include/footer.blade.php ENDPATH**/ ?>