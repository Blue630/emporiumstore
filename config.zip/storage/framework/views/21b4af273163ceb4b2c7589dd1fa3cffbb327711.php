 <?php $__env->startSection('content'); ?>

   
   
   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Sellers</h1>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Dashboard</li>
                            </ol>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
            <!-- Main content -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                <form method="post" action="<?php echo e(url('/admin/seller')); ?>">
                                <?php echo csrf_field(); ?>
                                    <div class="row">
                                       
                                        <div class="col-sm-3 sortby">
                                            <div class="flt-lft">
                                                <label>Status
                        <select class="form-control" style="width:140px;" name="seller_status">
                    <option selected="selected">--Select--</option>
                    <option value=1>Active</option>
                    <option value=0>Inactive</option>
                    </select>
                       </label>
                                            </div>
                                        </div>
                    <div class="col-sm-4 date-pickme">
                    <div class="flt-lft">
                    <label class="d-flex align-items-center">Date: 

                    <div class="input-group date reservationdate" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" name="date" data-target="#reservationdate"/>
                    <div class="input-group-append" data-target=".reservationdate" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                    </div>
                    </div>

                    </label>

                    </div>
                    </div>
                                        <div class="col-sm-3 search-ord">
                                            <input type="text" class="form-control" placeholder="Search" name="search">
                                        </div>
                                        <div class="col-sm-2">
                                            <button type="submit" class="btn btn-block btn-primary">Go!</button>
                                        </div>

                                    </div>
                                    </form>
                                    <div class="">
                                        <table class="table table-bordered table-responsive"  style="font-size:14px;">
                                            <thead>
                                                <tr>
                                                    <th>S.No</th>
                                                    <th>Seller Id</th>
                                                    <th>Seller Name</th>
                                                    <th>Email</th>
                                                    <th>Phone No</th>
                                                    <th>Address</th>
                                                    <th>Pincode</th>
                                                    <th>Date</th>
                                                    <th>Status</th>
                                                    <th>Seller Details</th>
                                                    <!-- <th>Action</th> -->
                                                    </tr>
                                            </thead>
                                            <tbody>

<?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$key++;
?>

                                                <tr>
                                                    <td><?php echo e($key); ?></td>
                                                    <td class="seller_id"><?php echo e($seller->uid); ?></td>
                                                    <td><?php echo e($seller->shop_name); ?></td>
                                                    <td><?php echo e($seller->email); ?></td>
                                                    <td><?php echo e($seller->phone); ?></td>
                                                    <td><?php echo e($seller->address); ?></td>
                                                    <td><?php echo e($seller->pincode); ?></td>
                                                    <td><?php echo e($seller->created_at); ?></td>
                                                    <td style="width:160px;">
                                                    <select class="form-control w-100 active-drop">
                                                        
                    <option <?php if($seller->status == 1): ?> selected <?php endif; ?> value="1">Active</option>
                    <option <?php if($seller->status == 0): ?> selected <?php endif; ?> value="0">Inactive</option>
                    </select></td>
                    <td><i class="fa fa-list-alt show-seller-popup" aria-hidden="true"></i></td>
                    <!-- <td><i class="fas fa-trash-alt delete-seller"></i></td> -->
                                                   </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-5">
                                        
                                            <div class="dataTables_info" id="example2_info" role="status" aria-live="polite">Showing 1 to 10 entries</div>
                                        </div>
                                        <div class="col-sm-12 col-md-7">
                                            <div class="table_page flt-rght">
                                            <?php echo e($sellers->links()); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <div class="modal fade show-slide-modal" id="showSlide" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
          
            <div class="modal-header"> 
              <h4 class="modal-title" id="exampleModalLongTitle" style="text-align:center">Seller  Details <?php //echo $statetable;?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="margin-top:-20px">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body" id="seller_details_div">
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
            
          </div>
        </div>


        </div>
        <script>

// SELLER CHANGE STATUS
$('.active-drop').change(function(){
let formdata = new FormData();
let seller_id = $(this).parent().parent().find(".seller_id").text();
let status = $(this).val();

formdata.append("change_seller_id",seller_id);
formdata.append("change_status",status);
$.ajaxSetup({
headers: {
'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
}
})

$.ajax({
type: "post",
url: "<?php echo e(url('/admin/seller')); ?>",
data:{"change_seller_id":seller_id,"change_status":status},
success: function(data){
    alert("Status Updated Successfully");
}
})
})


// SELLER DETAILS POPUP
$('.show-seller-popup').click(function(){
let seller_id = $(this).parent().parent().find(".seller_id").text();
    
$.ajaxSetup({
headers: {
'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
}
})

$.ajax({
type: "post",
url: "<?php echo e(url('/admin/seller-details')); ?>",
data:{"seller_id":seller_id},
success: function(data){
document.querySelector("#seller_details_div").innerHTML = data;
$("#showSlide").modal("show");
}
})
})

// DELETE SELLER
$('.delete-seller').click(function(){
let seller_id = $(this).parent().parent().find(".seller_id").text();

if (confirm('Are you sure you want to permanently delete this seller ?')) {

$.ajaxSetup({
headers: {
'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
}
})

$.ajax({
type: "post",
url: "<?php echo e(url('/admin/seller')); ?>",
data:{"delete_seller_id":seller_id},
success: function(data){
    location.reload();
}
})
}
})


</script>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/develsi8/public_html/laravel/resources/views/admin/seller/seller-listing.blade.php ENDPATH**/ ?>