<style>
    body {font-family:Helvetica, Arial, sans-serif; font-size:10pt;} 
    table {width:40%; border-collapse:collapse; border:1px solid #CCC;}
    td {padding:5px; border:1px solid #CCC; border-width:1px 0;}
    .inner{
        width:40%;border:groove;
    }
</style>

<body>
<div class="inner">
             <table align="center" border="1" width="100%">
         <tr>
         <td style="text-align:center; border:1px #CCCCCC solid;">Name</td>
         <td style="text-align:center; border:1px #CCCCCC solid;"><?php echo e($dataset['form_name']); ?></td> 
        </tr>
        <tr>
         <td style="text-align:center; border:1px #CCCCCC solid;">Email</td>
         <td style="text-align:center; border:1px #CCCCCC solid;"><?php echo e($dataset['form_email']); ?></td> 
        </tr>
        <tr>
         <td style="text-align:center; border:1px #CCCCCC solid;">Phone</td>
         <td style="text-align:center; border:1px #CCCCCC solid;"><?php echo e($dataset['form_phone']); ?></td> 
        </tr>
        <tr>
         <td style="text-align:center; border:1px #CCCCCC solid;">Subject</td>
         <td style="text-align:center; border:1px #CCCCCC solid;"><?php echo e($dataset['form_subject']); ?></td> 
        </tr>
        
        <tr>
         <td style="text-align:center; border:1px #CCCCCC solid;">Message</td>
         <td style="text-align:center; border:1px #CCCCCC solid;"><?php echo e($dataset['form_message']); ?></td> 
        </tr>
      </table>
  </div>
    </body>






<?php /**PATH E:\xampp\htdocs\ensurecare\resources\views/front/sendmail/contactmail.blade.php ENDPATH**/ ?>