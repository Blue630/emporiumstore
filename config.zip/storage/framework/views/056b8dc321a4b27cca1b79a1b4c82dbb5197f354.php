    <?php $__env->startSection('content'); ?>
        <section class="page-title centred" style="background-image: url(<?php echo e(asset('/public/front')); ?>/images/about/page-title.jpg);">
            <div class="container">
                <div class="content-box">
                    <div class="title"><h2>Become Partner</h2></div>
                </div>
            </div>
        </section>
        <section id="contact" class="contact-section sp-one">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                    </div>
                    <div class="col-md-6 col-xs-12 contact-column">
                        <?php if($msg=Session::get('success')): ?>
                        <div class="alert alert-success"><?php echo e($msg); ?></div>
                        <?php endif; ?>
                        <div class="contact-form-area">
                            <h3>Become Partner</h3>
                            <form method="post" action="<?php echo e(url('/become_partner_email')); ?>" id="contact-form" class="default-form">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <input type="text" name="name" placeholder="Your Name *" required>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <input type="email" name="email" placeholder="Email Address *" required>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <input type="text" name="phone" placeholder="Phone" required>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <input type="text" name="address" placeholder="address" required>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <textarea placeholder="Your Message" name="message"></textarea>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <button type="submit" name="submit-form">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-3">
                    </div>
                </div>
            </div>
        </section>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\clean-guys\resources\views//front/become-partner.blade.php ENDPATH**/ ?>