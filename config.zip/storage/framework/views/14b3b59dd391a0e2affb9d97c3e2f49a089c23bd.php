<header class="header header-1 header-desktop header-transparent header-white">
    <div class="container-fluid">
        <div class="row">
            <div class="col-10 col-md-10 col-lg-10 col-xl-10 pl-0">
                <div class="row">
                    <div class="site-branding">
                        <a class="normal_logo" href="#" rel="home">
                            <img src="<?php echo e(asset('/public/front')); ?>/images/logo-1.png" alt="" />
                        </a>
                    </div>
                    <nav class="main-navigation d-none d-lg-block">
                        <div class="primary-menu">
                            <ul class="main-menu">
                                <li class="menu-item-has-children mega-menu">
                                    <a href="<?php echo e(url('/')); ?>">Home</a>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="<?php echo e(url('/about-us')); ?>">About Us</a>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="<?php echo e(url('/product-list')); ?>">Premium Numbers</a>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">Offer Zone</a>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="<?php echo e(url('/contact-us')); ?>">Contact us</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-2 header-column-icon-container">
                <div class="header-icon header-icon-cart mini-cart d-none d-lg-block">
                    <div class="mini-cart__button">
                    <?php $cartitem = \Cart::getContent(); ?>
                       <a href="<?php echo e(url('/cart')); ?>"> <span class="mini-cart-icon" data-count="<?php echo e($cartitem->count()); ?>"></span></a>
                    </div>
                    <div class="widget-shopping-cart-content">
                        <ul class="cart-list">
                        <?php if(!empty($cartitem)): ?>
                            <?php $__currentLoopData = $cartitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <?php echo e($item->name); ?>

                            <br>
                            <?php echo e($item->price); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                            <li class="empty">No products in the cart.</li>
                        </ul>
                    </div>
                </div>
                <div class="header-icon header-icon-search d-none d-lg-block">
                    <i class="pe-7s-search"></i>
                </div>
                <div id="page-open-mobile-menu" class="page-open-mobile-menu d-lg-none">
                    <div><i></i></div>
                </div>
            </div>
        </div>
    </div>
</header>
<div id="page-mobile-main-menu" class="page-mobile-main-menu">
    <div class="page-mobile-menu-header">
        <div class="page-mobile-menu-logo">
            <a href="#">
                <img src="<?php echo e(asset('/public/front')); ?>/images/logo-1.png" alt="" />
            </a>
        </div>
        <div id="page-close-mobile-menu" class="page-close-mobile-menu">
            <div><i></i></div>
        </div>
    </div>
    <ul class="mobile-menu">
        <li>
            <a href="<?php echo e(url('/')); ?>">Home</a>
        </li>
        <li>
            <a href="<?php echo e(url('/about-us')); ?>">About us</a>
        </li>
        <li>
            <a href="<?php echo e(url('/product-list')); ?>">Premium Numbers</a>
        </li>
        <li>
            <a href="#">Offer Zone</a>
        </li>
        <li>
            <a href="<?php echo e(url('/contact-us')); ?>">Contact us</a>
        </li>
    </ul>
</div><?php /**PATH E:\xampp\htdocs\vip\resources\views/front/include/header.blade.php ENDPATH**/ ?>