<!--<footer class="main-footer text-center">
    <strong>Copyright &copy; 2021 <a href="#">Log Zero Technologies</a>.</strong>
    All rights reserved.
  </footer>-->
   