<!-- Bootstrap -->
<script src="{{asset('/public/admin')}}/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="{{asset('/public/admin')}}/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<!--<script src="{{asset('/public/admin')}}/dist/js/adminlte.js"></script>-->
<script src="{{asset('/public/admin')}}/dist/js/common.js"></script>
<!-- OPTIONAL SCRIPTS -->
<script src="{{asset('/public/admin')}}/dist/js/demo.js"></script>
<!-- PAGE PLUGINS -->
<!-- jQuery Mapael -->
<script src="{{asset('/public/admin')}}/plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
<script src="{{asset('/public/admin')}}/plugins/raphael/raphael.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/jquery-mapael/jquery.mapael.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/jquery-mapael/maps/usa_states.min.js"></script>
<!-- ChartJS -->
<script src="{{asset('/public/admin')}}/plugins/chart.js/Chart.min.js"></script>
<!-- PAGE SCRIPTS -->
<script src="{{asset('/public/admin')}}/dist/js/pages/dashboard2.js"></script>
<!--<script src="https://code.jquery.com/jquery-3.5.1.js"></script>-->
<!-- Data tables -->
<script src="{{asset('/public/admin')}}/plugins/moment/moment.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/jszip/jszip.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/pdfmake/pdfmake.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/pdfmake/vfs_fonts.js"></script>
<script src="{{asset('/public/admin')}}/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/daterangepicker/daterangepicker.js"></script>
<script src="{{asset('/public/admin')}}/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js"></script>
<script src="{{asset('/public/admin')}}/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script src="{{asset('/public/admin')}}/dist/js/pages/dashboard3.js"></script>