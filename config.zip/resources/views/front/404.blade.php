@include('front.include.header')
@yield('header')
<!-- content area start -->
<div class="container ab-w  my-5">
    <div class="page_title about_us position-relative">
        <img src="https://development-review.net/emporium/public/pages/1639725369_Rectangle 95.png" class="img-fluid d-block mx-auto" alt="">
        <h1 class="ft-60 lh-90 ft-bold">404<br>Not Found</h1>
    </div>
</div>
@include('front.include.footer')
@yield('footer')